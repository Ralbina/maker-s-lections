// let arrowFunc = () =>{
//     console.log("Hello World");
// }
// //todo тоже самое можно в одну строчку написать 
// let arrowFunc = () => console.log("Hello World");

// arrowFunc()



// let arrowFunc = (arg1, arg2) => {  
//     return arg1 + arg2
// }

// let arrowFunc = (arg1, arg2) =>  arg1 + arg2
// console.log(arrowFunc (7,8))


// let arrowFunc = (arg1) => console.log(arg1);
//  arrowFunc(5)


// todod в стрелочных функциях нет понятия arguments 
// let arrowFunc =(arg1, arg2, arg3) => {
//     console.log(...arguments);
// }
// arrowFunc(true,23,"makers")

//todo function dexpretion (анонимная ф-я)
// let arrowFunc = function (arg1, arg2, arg3)  {
//     console.log(...arguments);
// }
// arrowFunc(true,23,"makers")

//todo function dicloration 
// function  arrowFunc  (arg1, arg2, arg3)  {
//     console.log(...arguments);
// }
// arrowFunc(true,23,"makers")


// //todo Метод объкта
// let person = {
//     name: "Jack",
//     age: 22,

//     sayHello() {
//         console.log("Hello WOrld!");
//     },
//     sayName: function () {
//         console.log(`My name is ${this.name}`);//todo ${person.name} заменяем на слово this так как еогда обращаемся в person2 он берет данные с person 
//     },
//     sayAge: function () {

//         console.log(`I am ${this.age} y.o.`)
//     }
}
// console.log(person.age);
// person.sayHello()
// person.sayName()
// person.sayAge()

// let person2 = {...person}//todo скопируй мне содержимое person полностью и пометси его в person 2
 // console.log(person2);
// person2.name = "Kani";
// person2.age= "45";
// person2.sayName()
//     person2.sayAge()



// let obj1= {
//     name: "Kani",
//     age:20,
//     obj2: {
//         name: "Kubat",
//         sayName:() => {
//             console.log(`${this.name}`);//todo this берет данные у родительской ф-ии
//         }
//     }
// }
// obj1.obj2.sayName()



// alert("qwerty");
// console.log(this);//todo если мы обращаемся на клобальном уровне то в this находится window
// window.alert("Hello!")//* это равнозначная запись

// let obj = {
//     alert(a) {
//         console.log(a + "OBJ1");
//     },
//     hello:  ()=> {
//         let obj2 = {
//             alert(a) {
//                 console.log(a + "OBJ2");
//             },
//             hello2:() => {
//                 this.alert("ALERT")
//             }
//         }
//         obj2.hello2()
//     }

// }
// obj1.hello()


//!Разбор классно работы


// Стрелочные функции, методы объектов, this. Классная работа

// !Задание №1
//todo Создайте стрелочную функцию, которая принимает 2 аргумента и  возвращает сумму всех аргументов.
//  let arrowFunc = (arg1,arg2) => arg1+arg2
// console.log(arrowFunc(6,7));
//! Задание №2
// Создайте объект user со свойствами name, surname и age.
//  let user={
//      name:"Albina",
//      surname: "Rahmanova",
//      age: 29,

//  }

// !Задание №3
//todo Создайте у объекта user метод SayHi, который будет выводить в консоль “Hello World”.

// let user={
//     name:"Albina",
//     surname: "Rahmanova",
//     age: 29,
//     sayHi: function() {
//         console.log("Hello World");
//     }

// }
// user.sayHi()
//! Задание №4
// todo Создайте метод у объекта user, который будет выводить в консоль  его возраст.

// let user = {
//     age: 29,
//     sayAge: function(){
//         console.log(user.age);
//     }

// }
// user.sayAge()

// !Задание №5
// todo Создайте метод у user, который будет возвращать полную информацию. Например: Homer Simpson 40

// let user = {
//     name: "Albina",
//     surname: "Rahmanova",
//     age: 29,

//     sayInfo() {
//         console.log(`${user.name} ${user.surname} ${user.age}`);
//     }
// }
// user.sayInfo()
//! Задание №6
//todo  Сделайте 3 и 4 задание используя this.

// let user={
//     name:"Albina",
//     surname: "Rahmanova",
//     age: 29,
//     hi: "Hello World",
//     sayHi: function() {
//         console.log(this.hi);
//     },
//     sayAge: function(){
//             console.log(this.age);
//         }
//     }
//     user.sayHi()
//     user.sayAge()

    // let checkTask={
    // name:"Albina",
    // age: 29,
    // sayHi: function() {
    //     console.log(`Happy Birthday ${this.name}!`);
    // },
    // sayAge: function(){

    //         console.log(`You are ${this.age}!`);
    //     }
    
    // }
    // checkTask.sayHi()
    // checkTask.sayAge()