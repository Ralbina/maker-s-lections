// todo Замыкание 
//* через глобальную переменную

// let count = 0;
// function counter(){
//     count++
//     return count
// }
// counter();
// counter();
// console.log(counter()); 


// function counter(){
//     let count = 0;
//     count++
//   return function(){
//       count++
//       return count
//   }
// }
// let first = counter();
// console.log(first()); 
// first();
// console.log(first());

//todo Рекурсия  в рекурсии каждый круг останавливается и ждет завершение следующего если след функцтя не завершится эта тоже не завершится

let x=0;
function rec(){
    if(x<=5){
        console.log(x++);
        rec()
    }
}
rec()

// let arrNums=[1,2,3,4];
// let i=0;

// function rec(arr, sum){
//     i++
//     console.log(`функция ${i} началась`);
//     sum +=arr.shift();
//     if(arr.length !=0){
//         sum = rec(arr,sum)
//     }
//     console.log(`функция ${i} завершилась`);
//     i--
//     return sum
// }
// console.log(rec(arrNums, 0));

//todo Цикл ( быстрее каждый круг заверщается и не жет выполнения след круга)


// let arrNums=[1,2,3,4];
// let sum=0
// for (let i=0; i<arrNums.length; i++){
//     console.log(`${i}круг`);
//     sum +=arrNums[i]
// }
// console.log(sum);


//todo Задание №4
// Создайте функцию, которая будет проверять - чётное ли число, или нечетное? В случае если число чётное - верните True, если нечётное - False

// Например
// console.log(recEven(234)); // выведет true
// console.log(recEven(-45)); // выведет false
// console.log(recEven(37)); // выведет false



// function recEven(number){
//     let x = new Boolean(false);
//     if( number % 2 == 0){
//     return true;
//     }else{
//     return false;
//     }
//     }
//     console.log(recEven(28));

//todo Задание №2
// 	Создайте функцию, которая запрашивает у
// пользователя число(в качестве порядкового
// числа по Фибоначи), затем выводит в консоли
// число Фибоначи по этому порядку.
// Например:
//    Ввод: 10;
//    Вывод: 55
// Числа Фибоначчи (ссылка):
// https://shorturl.at/cvE17


// function fib(n){
//     if(n>1){
//         return fib (n-1)+ fib(n-2)
//     } else{
//         return n 
//     }
// }
// console.log(fib(8));
// function num (i){
//     return sum (i--)
// }
// console.log(num(5));

//todo Задание №3
// Создайте функцию, которая преобразовывает
// многомерный массив arr в одномерный массив.
// При помощи рекурсии!

// let arr = [1, [true], [[3], ["hello"]]];
// Вывод: [1,true,3,'hello'];




// let arr=[1,[true],[[3],["hello"]]];
// let newArr=[];
// const arrToFloat = function(arr, i=0){
//     if(i===arr.length) return;
//     if(Array.isArray(arr[i])) arrToFloat(arr[i])
//     else newArr.push(arr[i])
//     arrToFloat(arr,i+1)
// }
// arrToFloat(arr);
// console.log(newArr);