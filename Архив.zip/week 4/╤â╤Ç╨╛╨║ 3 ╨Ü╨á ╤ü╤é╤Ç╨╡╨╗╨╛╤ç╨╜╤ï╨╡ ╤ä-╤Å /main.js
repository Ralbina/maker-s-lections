// //Arrow.sort((a,b) =>a-b);
// // const getSum=(x,y) => {
// //     return x+y;
// // };
// // console.log(getSum(5,4));



// // const sum = x => (typeof x === "number" ? "yes": "no");
// // console.log(sum(10));



// //!arguments не будет работать 
// // function func (a,b,c){
// //     console.log(arguments);
// // }
// // func (10,20,30)


// // const someFunc =(a,b,c) => console.log(arguments);
// // someFunc (40,20,50)


// //TODO 1. Напишите стрелочную функцию, которая принимает в качестве параметра километры и возвращает метры. Функцию с начала напишите в несколько строк (тело функции в фигурных скобках. Затем, функцию сократите до одной строки.
// // let km = (a)=> a*1000;
// // console.log(km(7));

// //второй вариант
// // let km = (a)=>{ 
// //    return  a*1000
// // }

// //TODO 2. У вас есть массив:  const numbers = [3, 62, 234, 7, 23, 74, 23, 76, 92]; С помощью стрелочной функции отфильтруйте и создайте новый массив с числами больше 70

// // const numbers = [3, 62, 234, 7, 23, 74, 23, 76, 92]  
// // let num=(somearr)=>{ 
// //     let arr=[] 
// //     for (let i = 0; i < somearr.length; i++) { 
// //         if(somearr[i] >70){ 
// //             arr.push(somearr[i]) 
// //         }    
// //     } 
// //     return console.log(arr); 
// // }
// // num(numbers)


// //todo второй способ Метод массова
// // const numbers = [3, 62, 234, 7, 23, 74, 23, 76, 92];
// // const filtered= numbers.filter((number)=>number>70);
// // console.log(filtered);


// //!Методы объект
// // let airplane={
// //     type: "Boeling",
// //     isActive:vtrue,
// //     inService:864,
// //     fly: function (city){
// //         console.log(` Летит в ${city}`);
// //     },
// //     }
// // airplane.fly("bishkek"); //летит в Бишкек

// // fly("Bishkek")//todo Error





// console.log(window);
// // console.log(navigator);
// // console.log(navigator.platform);
// // console.log(navigator.href);
// // console.log(navigator.screen);


// //todo обощли что this не работает в стрелочных ф-и
// // let user ={
// //     name: "John",
// //     sayHi(){
// //         let arrow = ()=> alert(this.name);
// //         arrow();
// //     },
// // };
// // user.sayHi();


// //TODO Задачи:

// //TODO 1. Дан объект passenger. Напишите метод для этого объекта,который возвращает информацию о пассажире. Также, напишите второй метод, который меняет значение свойства baggage на то значение, которое получает в качестве параметра.
// //!первый способ
// // let passenger = { 
// //     firstName: 'Sam', 
// //     lastName: 'Winchester', 
// //     passportNum: 'US12345678', 
// //     baggage: 20, 
// //     getInfo(){ 
// //         console.log(`Passenger ${this.firstName} ${this.lastName}. Passport number is ${this.passportNum}. Maximum luggage weight is ${this.baggage}kg`) 
// //     }, 

// //     setBaggage(){ 
// //         this.baggage = this.baggage + 10 
// //     } 
// // };
// // Пример
// //   passenger.getInfo(); // Passenger Sam Winchester. Passport number is US12345678. Maximum luggage weight is 20kg
// //   passenger.setBaggage(30);
// //   passenger.getInfo(); // Passenger Sam Winchester. Passport number is US12345678. Maximum luggage weight is 30kg


// //!второй спосоюб
// //   let passenger = {
// //     firstName: 'Sam',
// //     lastName: 'Winchester',
// //     passportNum: 'US12345678',
// //     baggage: 20,
// //   };

// //   passenger.getInfo = function () {
// //     console.log(
// //       Passenger ${this.firstName} ${this.lastName}. Passport number is ${this.passportNum}. Maximum luggage weight is ${this.baggage}kg
// //     );
// //   };

// //   passenger.setBaggage = function (kg) {
// //     this.baggage = kg;
// //   };

// //TODO 3. Создайте объект calculator (калькулятор) с тремя методами: read() (читать) запрашивает два значения и сохраняет их как свойства объекта. sum() (суммировать) возвращает сумму сохранённых значений. mul() (умножить) перемножает сохранённые значения и возвращает результат.
// //!первый способ
// // let calc = { 
// //     read(a,b) { 
// //     return(console.log(a, b)); 
// //     }, 

// //     sum(a,b) { 
// //     return(console.log(a + b)) 
// //     }, 

// //     mul(a,b){ 
// //     return console.log(a*b); 

// //     }, 
// // } 

// // calc.read(5,6) 
// // calc.sum(5,6) 
// // calc.mul(5,6)

// //!второй способ с помошью this( кошда пишем prompt значение приходит ввиде строки)
// // let calc = {
// //     read() {
// //       this.a = +prompt('A?');//* + что бы переделать формат цифры в формат строки
// //       this.b = +prompt('B?');
// //     },
// //     sum() {
// //       return this.a + this.b;
// //     },
// //     mul() {
// //       return this.a * this.b;
// //     },
// //   };

// // console.log(calc);// это до
// // calc.read();
// // console.log(calc); // два раза что это после
// // alert(calc.sum());
// // alert(calc.mul());

// //!! Задание такски
// // Напишите стрелочную функцию checkTask(), которая принимает в аргументы массив со строками.

// // Добавьте к концу каждой строки массива строку 'is cool'.

// // Выведите массив в консоль.

// // К примеру при передачи в аргументы данного массива ['John', 'Mike', 'Rick', 'Drake'], вывод будет:

// // ['John is cool', 'Mike is cool', 'Rick is cool', 'Drake is cool'] 
// // используйте цикл for

// // let arr = ['John', 'Mike', 'Rick', 'Drake'];
// // let checkTask = (arr) => {
// //   for (let i = 0; i < arr.length; i++) {
// //     arr[i] = `${arr[i]} is cool`
// //      }
// // return console.log(arr)
// //  }
// // checkTask(arr)

// var arr = [1,5,66,150,0];
// 2
// alert(("" + arr[2]).length);

// let arrowFunc = (arg) => arg="Kubat"
// alert ("")
// console.log(arrowFunc(6,7));

// let arrowFunc = (arg) => arg="Kubat"
// alert ("Helo, Kubat")
// console.log(arrowFunc(Kubat));

