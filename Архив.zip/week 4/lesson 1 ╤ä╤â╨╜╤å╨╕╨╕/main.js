// // // //локальная функция
// // // function greet(){
// // //     console.log("Hello");
// // // }
// // // greet();//вызываем а функцию


// // function countUntil(){
// //     for(let i =1; i<= 10; i++){
// //         console.log(i);
// //     }
// // }
// // // countUntil();

// // function countUntil(num){
// //     for(let i =1; i<= num; i++){
// //         console.log(i);
// //     }
// // }
// // // countUntil(5);
// // // countUntil(40);


// // function congrats(name, lastname){
// //     console.log(`Поздравляю ${name} ${lastname} с успешным проходлением теста`);
// // }
// // // congrats ("Jack", "Doe")



// // // ! RETURN - то что возвращает функция
// // function calcTriangleSquare(base, height){
// // return(1/2)*base*height;
// // }
// // // console.log( calcTriangleSquare(20,6));
// // //  второй способ
// // let square = calcTriangleSquare(20,6);
// // // console.log(square);


// // const person = {
// //     name: 'Alex',
// //     salary: 30000,

// // };

// // function givePremium(salary, percent){
// //     return (salary * percent) / 100;
// // }

// // // person.premium = givePremium(person.salary, 10)
// // // console.log(person);


// // //return реально уже выполняет действие и уже не пишет в консоле 
// // function checkAge(age){
// //     if(age>18){
// //         return console.log("Welcome");

// //     }else{
// //         return console.log( "Not welcome");
// //     }
// // }
// // // let userAge = prompt ("Enter your age")
// // // checkAge(userAge);


// // //return без значения это немедденный выход из функции
// // function checkType(elem){
// //     if (!elem) return;//просто прекрати дальнейшую проверку
// //     console.log("Это элемент типа ${typeof elem}");
// // }
// // checkType("makers");
// // checkType(0)

// // function getCube(num){
// //     return num * num;
// // }
// // console.log(getCube(2));


// // function getCube(num){
// //     console.log( num * num);
// // }
// // getCube(5);
// // console.log(getCube(2));

  
// // Задачи

// // todo Напишите программу на JavaScript для вычисления суммы двух заданных целых чисел. Если два значения одинаковы, то возвращается тройная их сумма.

// function getSum (num1, num2){ 
//     if(num1 === num2){ 
//         return 3* (num1+num2) 
//     }else{ 
//         return num1+num2 
//     } 
// } 
 
// // console.log(getSum(2,1))

// //todo Напишите функцию pow(x,n) которая возвращает x в степени n. Другими словами умножьте x на себя n раз

// function pow(x,n){
//     if (n>0){
//         return x**n
//     }
// }
// // console.log(pow(4,6));

// // let message="Hello" //глобальная переменная
// // function schowMess(){
// //     let message = "Ohaya";
// //     console.log(message);
// // }
// // schowMess();



// // !!!! объект Argument нужен что бы ссылаться на аргументы этой же самой фукции внутри , снаружи уже это сделать нельзя
// function func(a, b, c, d, e){
//     console.log(a, b, c, d, e);
//     console.log(...arguments);//показывает скопированные данные ввиде обычных чисел 
//     console.log(arguments);//тут показываем именно массивноподобнвй объект
//     console.log([...arguments]);
//     console.log(arguments(0));
//     console.log(arguments.length);//показывет  количество элементов
// }

// // func( 10, 20, 30, 40, 50);


// // !!!!! Hoisting

// // const name ="James";
// let info ="some info";
// var city= "Bishkek";

// // console.log(name);
// // console.log(info);
// // console.log(Bishkek);

// // function sum(a,b){
// //     let sum
// //     return a+b;
// // }
// // console.log(sum(2.3));


// // !function expression
// // let cub= (function(){
// //     console.log(2 * 3);
// // })();

// //todo Напишите функцию, которая принимает строку в аргументы и считает количество гласных букв в строке

// // let arr =[2, 3, 9];
// // console.log(arr,index0f(2));
// // console.log(arr,index0f(5));


// function sum(string) { 
    
//     let vowels= "aoeiuAOEIU";
//     let count=0;
//     for(let x=0; x<string.lenght; x++){
//         // console.log(string[x]);
//         if(vowels.indexOf(string[x]) [== -1]{

//         }
//     }
// }
// sum("Hello world");


var randomBodyParts = ["глаз", "нос", "череп"];
var randomAdjectives = ["вонючая", "унылая", "дурацкая"];
var randomWords = ["муха", "выдра", "дубина", "мартышка", "крыса"];
 randomBodyParts:
var randomBodyPart = randomBodyParts[Math.floor(Math.random() * 3)]; randomAdjectives:
var randomAdjective = randomAdjectives[Math.floor(Math.random() * 3)];
var randomWord = randomWords[Math.floor(Math.random() * 5)];


var randomInsult = "У тебя " + randomBodyPart + " словно " + 
randomAdjective + " " + randomWord + "!!!";
console.log(randomInsult);