// const str= "Hello! My name is Albina. I am 29 years old and I live in Bishkek for 12 years";
// const regexp = /Albina/;
// const regexp = /\d\d/g;//todo ищет число в тексте (посик идет слева на право)
// const regexp = /\w/;//todo для поиска букв но не киррилици
// const regexp =/\W\W\W/;//ищет русские буквы
// const regexp =/\D\D///todoищем люьой символ кроме цифрж

// const str= "Hello! My name is Ulan and Alan and Elan"
// const regexp = /[AUE]lan/g ///todo ищет любой символ из набора
// const result = str.match(regexp);//todo match возыращвкт нам массив
// console.log(result);

// const str= "Today is 20.10.2020"
// const regexp = /\d\d.\d\d.\d\d\d\d/
// const regexp = /\d{2}.\d{2}.\d{4}/ //todoболее сокращенная запись
// const regexp =/\./ //todo ищем именно точку
// const result = str.match(regexp);//todo match возыращвкт нам массив
// console.log(result);

//  let str = "We see you. we need you";
//  let pattern = /we/gi;//todo i это игнорирование регистара
//  console.log(str.replace(pattern,"I"));//todo Заменяем we на I

// let str = prompt ("Enter world:");
// let regexp = new RegExp(/[a-zA-ZА-Яа-я]/, "g");
// console.log(regexp.test(str)); //todo  метод test возвращает нам true или false

// let str = prompt ("Enter world");
// let regexp=new RegExp (/\d+/, "g");//todo + это от 1 и более  Мы в нашем вырадении ищем хотя бы один цифру и более
// console.log(regexp.test(str));

// let str =prompt ("Enter product weight");
// let regexp = new RegExp(/^\d+(kg|t|g)$/,"gi")//todo ^ -это означает начало значит с самого начала должна идти цифра а $ это конец
// console.log(regexp.test(str))

// let str = "Name:Jack , LastName : Smith";
//todo простой способ
// let newArr=[];
// for (let i=0, i< str.length;i++){
//     if(str[i].toLocaleLowerCase() !=="a")newArr.push(str[i])//todo если в нашей строке какой то эл-т под определенным индексом он будет не равен букве 'a' мы будем пушить нащ элемент
//     else newArr.push("*")
// }
// let newStr = newArr.join("");
// console.log(newStr);

//todo другой способ короче
// console.log(str.replace(/a/gi, "*"));

// let str = prompt ("Enter your phone number:");
// let regexp = new RegExp(/^\+996\d{9}/, "g");
// // console.log(regexp.test(str));

// if(regexp.test(str)){
//     alert ("Correct")
// } else {
//     alert("Wrong")
// }

/**
 //todo Задание №1
 * Написать регулярное выражение, заставляющее
 * вводить не менее 5 алфавитно-цифровых символов.
 * */

// let str= prompt ("Enter word:");

// if ((/[A-Za-z0-9а-яА-Я]{5,}/).test(str)){
//     alert("correct")
// }else {
//     alert("Wrong")
// }

/**
 * 
 //todo Задание №2
 * Дана строка 'aba aca aea abba adca abea'.
 * Напишите регулярку, которая найдет строки
 * abba и abea, не захватив adca.
 */

// const str= "aba aca aea abba adca abea"
// const regexp = (/ab.a/gi) ///todo ищет любой символ из набора
// const result = str.match(regexp);//todo match возыращвкт нам массив
// console.log(result);
/**
 //todo Задание №3
 * Дана строка '23 2+3 2++3 2+++3 345 567'.
 * Напишите регулярку, которая найдет строки 2+3,
 * 2++3, 2+++3, не захватив остальные
 * (+ может быть любое количество).
 */

//  const str= ("23 2+3 2++3 2+++3 345 567")
//  const regexp = (/2\++3/gi)
//  const result = str.match(regexp);//todo match возыращвкт нам массив
//  console.log(result);

//todo ТАСКИ
// Задание 2
// Дана строка 'aaa aaa aaa'.

// Напишите регулярное выражение, которое заменит первые три 'aaa' на '!'.

// Вывод должен быть:

// ! aaa aaa

//  let str = 'aaa aaa aaa';
// function checkTask(str){
// console.log((str).replace(/aaa/, '!'));
// }

//!Задание 3
// Дана строка 'a1a a2a a3a a4a a5a aba aca'.

// Напишите регулярное выражение, которое найдет строки, в которых по краям стоят буквы 'a', а между ними одна цифра.

// Замените данные строки на знак $.

// Вывод должен быть:

// $ $ $ $ $ aba aca

// let str='a1a a2a a3a a4a a5a aba aca';
// function checkTask(str){
//      console.log((str).replace(/a\da/g, '$'));
// }
// //!!
// let text = "la laa laaand"

// let pattern = /a+/g
// text.match(pattern) // [ 'a', 'aa', 'aaa' ]

// //!!
// let text = "la laa laaand"

// let pattern = /a+/g
// text.match(pattern) // [ 'a', 'aa', 'aaa' ]

// //!!
// let text = "l la laa laaand"

// let pattern = /la*/g //
// text.match(pattern) // [ 'l', 'la', 'laa', 'laaa' ]

// //!!
// let text = "l la laa laaand"

// //ищем подстроки у которых три "a"
// let pattern = /la{3}/g
// text.match(pattern) // [ 'laaa' ]

// // указав только начало и проставив запятую, можем найти все подстроки с двумя и более "a"
// let pattern2 = /la{2,}/g
// text.match(pattern2) // [ 'laa', 'laaa' ]

// !Задание 4
// Дана строка 'a1a a22a a333a a4444a a55555a aba aca'.

// Напишите регулярное выражение, которое найдет строки, в которых по краям стоят буквы 'a', а между ними любое количество цифр и замените их на строку Hy.

// Вывод должен быть:

// Hy Hy Hy Hy Hy aba aca

// let str = "a1a a22a a333a a4444a a55555a aba aca";
// function checkTask(str) {
//   console.log(str.replace(/a\d+a/g, "Ну"));
// }
// checkTask(str);

// function sum(a,b,c){
//     return (a-b)/c;
// }
// console.log(sum(50,30,5));

//! Задание 5
// Дана строка 'aAXa aeffa aGha aza ax23a a3sSa'.

// Напишите регулярное выражение, которое найдет строки следующего вида:

// по краям стоят буквы 'a'
// между буквами 'a' маленькие латинские буквы
// Замените данные строки на строку Good.

// Вывод должен быть:

// aAXa Good aGha Good ax23a a3sSa

// let str = 'aAXa aeffa aGha aza ax23a a3sSa'
// function checkTask(str){
//     console.log((str).replace(/a[a-z]+a/g, 'Good'))
// }

//  !Задание 6
// Дана строка 'ae1ea aeea a3544a a1a axxa axxxa'.

// Напишите регулярное выражение, которое найдет строки следующего вида:

// по краям стоят буквы 'a'
// между буквами 'a' стоят буквы 'e' или 'x' в любом количестве
// Замените их на строку many.

// Вывод должен быть:

// ae1ea many a3544a a1a many many

// let str = 'ae1ea aeea a3544a a1a axxa axxxa'
// function checkTask(str){
//     console.log((str).replace(/a(e|x)+a/g, 'many'))
// }

//!! Задание 7
// Дана строка с целыми числами.

// С помощью регулярного выражения преобразуйте строку так, чтобы вместо этих чисел стояли их квадраты.

// К примеру, если строка выглядит так '10 6 3 2', то вывод будет:

// 100 36 9 4

// let str = '10 6 3 2'
// function checkTask(str){
// let regexp = /[0-9]+/g;
//  str = str.replace(regexp, function (r) {
//  return r * r;
// });
// return console.log(str)
// }
// checkTask(str)

//todo Задание 8
// Дана строка с целыми числами.

// Найдите числа, стоящие в кавычках и увеличьте их в два раза.

// К примеру, для строки "2aaa'3'bbb'4'" , вывод будет:

// let str = "2aaa'3'bbb'4'"
// function checkTask(str){
// let regexp = /\d+(?=')/g;
//  str = str.replace(regexp, function (r) {
//  return r * 2;
// });
// return console.log(str)
// }
// checkTask(str)

// todo Задание 9
// Дана строка '23 + 35 ='. Числа могут быть любыми.

// Выведите на экран результат операции, используя регулярные выражения.

// Вывод должен быть:

// 23 + 35 =58

// let str = '23 + 35 =';
// function checkTask(str){
//     let regexp = /(\d+)\s\+\s(\d+)\s=/g;
//     str = str.replace (regexp, function (match, match1, match2) {
//                 let res = parseInt(match1) + parseInt(match2);
//                  return match + res;
//                 });
//             return console.log(str)
//         }
//         checkTask(str)

// todo Задание 10
// С помощью метода test определите, что год находится в интервале от 1900 до 2100 используя только одно регулярное выражение.

// Для '1955' , вывод будет:

// true
// Для '2200', вывод будет:

// false

// let str = '1955'
// function checkTask(str){
// 	console.log(/^(19\d\d|20\d\d|2100)$/.test(str));
// }

//todo Задание 11
// С помощью test определите, что переданная строка является корректным временем вида '12:59', '23:41', '00:12', '00:00', '09:15'.

// Время '24.00', '25.00', '12.60', '12.93', '41.93' является некорректным.

// Для ввода '09:15', вывод будет:

// true
// Для ввода '25.00' :

// false

//?первый способ
// let str='09:15'
// function checkTask(str){

//    console.log(/[0-2][0-9]:[0-5][0-9]/ .test(str));
// }

//?Второй способ
// let str='09:15'
// function checkTask(str){
//     let regexp = /[0-2][0-9]:[0-5][0-9]/
//     return console.log(regexp.test(str));
// }
// checkTask(str)

// todo Задание 12
// С помощью test, определите, что переданная строка является доменом. Примеры доменов: site.ru, site.com, my-site.com.

// Для ввода 'google', вывод будет:

// false
// A 'google.com' :

// true

// let str='google'
// function checkTask(str){
// 	 console.log(/(com||ru)$/.test(str));
// }

//todo Задание 13
// Создайте шаблон RegExp находящий все повторяющиеся слова в строке и удалите дубликаты.

// К примеру, для строки 'dsf xxx xxx sd' , вывод будет:

// dsf xxx sd

// function checkTask(str){
//     let RegEx =new RegExp ((/\b(\w+)\b(?:\s+\1\b)+/g),'g');
// str = str.replace(RegEx,'$1')
// return console.log(str)
// }

// todo Задание 14
// С помощью RegExp посчитайте количество слов в строке.

// Примечание: удалите пробелы из начальной и конечной позиции, а также преобразуйте 2 и более пробела в 1

// К примеру, для строки 'this string has five words' , вывод будет:

// 5

// function checkTask(str){
//     let sum = 1;
//     str=str.replace(/[\s]+/gi, ' ');
//     str.replace(/(\s+)/g, function (a) {
//        sum++;
//     });
//     return console.log(sum);
// }

//todo Задание 15
// Напишите регулярное выражение, разделяющее запятыми целое число. Запятая должна быть тысячным разделителем.

// К примеру, для '1000' , вывод будет:

// 1,000
// Для '10000000000':

// 10,000,000,000

// let str = '10015394680000';
// function checkTask(str) {
//     return console.log(str.replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ","))
// }
// checkTask(str);
