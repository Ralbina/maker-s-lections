//todo let regex = new Regex ("шаблон" , "флаги")
//todo let regex = /шаблон/флаги;

// let myStr= "I believe I can fly. I believe I can touch this sky"
//? MATCH -ищет совпадения в виде массива
//? строка.match(шаблон)
// let pattern = /I/gi;
// let res = myStr.match(pattern);
// console.log(res);


//?replace он заменяет найденое на другую строку
//? строка.replace(шаблон, замена)
// let str= "TypeScript";
// let pattern= /Type/;
// let newStr = str.replace(pattern,"Java");

// console.log(newStr);  //?JavaScript


//?test проверяет есть ли совпадения (true/false)
//? шаблон.test ( строка)


 let str ="UserName:'john24', user: 'John Doe'"
let regex =/user/i;
console.log(regex.test(str));

//? Search возвращает позицию первого совпадения или -1 если нет совпадения
//? str.search(regex)
// let str= "I ponder of something great";
// let regex=/of/;
// console.log(str.search(regex));


//! Символьные классы 
// let str= "Новейшим телефоном в линейке iphone является Iphone13";
// let regex=/Iphone\d/;
// console.log(regex.test(str));



//? \D не цифры

// let password ="qwerty123";
// let pattern=/\D/g;
// console.log(pattern.text(password)); //*будет correct потому что там есть значения не цифры


//? \s пробел
// let text= "Ineedsomespace";
// let pattern=/\s/g;
// console.log(pattern.text(text)); //*будет false потому что пробелов тут нет 

//? \S все кроме \s
// let text= "I have some space";
// let pattern=/\S/g;
// console.log(text.match(pattern));//*он нащел все что не является пробелом

//? \w латиница,цифры и __
// let text ="Это кириллица и он должен возратить "
//let pattern = /\w/g  //? не читатет русские буквы 
// console.log(text.match(pattern));




// let text ="That is the hottest hit"
// let pattern = /h.t/g;
// console.log(text.match(pattern));



//! Квантификаторы
//todo + один и более
//todo * нуль и более
//todo ? ноль или один
//todo {n} количество
//todo {n,x} диапазон
//todo {n, } n и более

// alert ('I was born in 1900' .match (/d/))

// console.log("Мне не 30 , а 1234".match (/\d{4,5}/));


let str = "+(996)-555-12-23-34";
let numbers=str.match(/\d{1,}/g);//задает диапозон > потому что там есть знаки между цифрами
console.log(numbers(str));

// let text = "it's in the old district, two blocks down the old house"

// let pattern = /old(?=\shouse)/
// console.log(text.search(pattern) ); 