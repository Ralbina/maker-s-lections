// let list =[
//     "Milk",
//     "Sugar",
//     "Salt",
//     "Butter",
//     "Bread"
// ]
// console.log(list[3]);//*Butter


// let [first,second,...other]=list;
// console.log(first,second,other);
///*Milk Sugar (3) ['Salt', 'Butter', 'Bread']

//!
// let arr =[
//     [1,2,3,4],
//     [5,6,7,8]
// ];
// let [[a,b,c,d],newArr]=arr //?[a,b,c,d]-деструетизируем
// console.log(a,b,c,d,newArr);
//1 2 3 4 (4) [5, 6, 7, 8]

//!

// let [[a,b,c,d],[newArr,...other]]=arr;
// console.log(a,b,c,d,newArr,other)
//*1 2 3 4 5 (3) [6, 7, 8]


//!пример

// let arr =[
//         [1,2,3,4,[9,0]],
//         [5,6,7,8]
//     ];
//     let [[a,b,c,d,[nine,zero]],[newArr,...other]]=arr;
//     console.log(a,b,c,d,newArr,other);
// console.log(nine,zero);

///*1 2 3 4 5 (3) [6, 7, 8]
// *9 0


//!пример
// let person={
//         age:30,
//         name:'John',
//         lastname:"Snow"
//     };
//     // let name=person.name;
//     // let age=person.age;
//     // let lastname=person.lastname;
// //? способ короче
//     let{age,name,lastname}=person;
//     console.log(name,age,lastname);


//!пример

// let obj1 ={ 
//     subObj: {
//         name:"Jack"
//     }
// };
// let {subObj:{name}}=obj1;
// console.log(name);
// //*Jack


//!пример

// let obj = {
//     arr:[
//         {
//             name:"Makers"
//         }
//     ]
// }
// let {arr:[{name}]}=obj
// console.log(name);
//*Makers


//!пример
// function foo({name,age}){
//     console.log(name,age);//* Makers,2
// }
// let person={
//     name:"Makers",
//     lastName:"Bootcamp",
//     age:2
// };
// foo(person)


// //?хочу работать с 4 элемента
// let arr= [1,2,3,4,5];
// let [,,,four,five]=arr    //?,-это пропуская первый элемент массива
// console.log(four,five);



//!Spread

// function foo(a,b,c,d,e){
//     console.log(a,b,c,d,e);
// };
// let arr= [1,2,3,4,5];
// foo(...arr);//*1,2,3,4,5


// let a={
//     age:20
// };
// // let b={
// //     age:20
// // };
// let b={...a} //? ccылочные типы данных
// b.age=30
// console.log(a,b);
// console.log(a===b);


//!пример

// let obj1={
//     name:"Kani",
//     color:"yellow"
// };
// let obj2={
//     lastName:"East",
//     // color:"pink"
// };

// let{color}=obj1;
// let newObj = {color,...obj2}
// console.log(newObj);


//!пример

// let obj = {
//     name: "Kani",
//     age: 22,
//     positions: [
//         "Mentor",
//         "Backend-developer",
//         "Frontend-developer",
//         "Bloger"
//     ],
//     dog: {
//         name: "oreo",
//         age: 2
//     }
// };

// let {
//     name,
//     age,
//     positions: [
//         firstPosition,
//         secondPosition,
//         ...otherPositions
//     ],
//     dog: {
//         name: dogName,   //? переименовываем потому что name уже есть 
//         age: dogAge
//     }
// } = obj;
// console.log(name, age, firstPosition, secondPosition, ...otherPositions, dogName, dogAge);

//*Kani 22 Mentor Backend-developer Frontend-developer Bloger oreo 2
// let {name,age}=obj
// console.log(name,age);


//!пример 

// let obj = {
//     name: "Kani",
//     age: 22,
//     positions: [
//         "Mentor",
//         "Backend-developer",
//         "Frontend-developer",
//         "Bloger"
//     ],
//     dog: {
//         name: "oreo",
//         age: 2
//     }
// };
//todo бкз декструктиризации выглядило бы так
// function sayHello(obj){
//     console.log(`
//     Hello,my name is ${obj.name}
//     I am ${obj.age}
//     I have a dog${obj.dogName}
//     `);
// }
// sayHello(obj)
//todo с декструктиризацией буде так 
// function sayHello({name,age,dog:{name:dogName}}){
//     console.log(`
//     Hello,my name is ${name}
//     I am ${obj.age}
//     I have a dog${dogName}
//     `);
// }
// sayHello(obj)
// //* Hello,my name is Kani
// *I am 22
//* I have a dogoreo



//!! CLASS WORK
//TODO Задание №1
// Дан массив [ "первый", "второй","третий", "четвертый","пятый","шестой","седьмой" ];
// Запишите первый элемент этого массива впеременную elem1,
// второй - в переменную elem2, третий - в переменную elem3,
// а все остальные элементы массива - в переменную arr.

// let str= [ "первый", "второй","третий", "четвертый","пятый","шестой","седьмой" ];
// let [elem1,elem2,elem3,...arr]=str
// console.log(elem1,elem2,elem3,arr);


// let arr =[
//     [1,2,3,4],
//     [5,6,7,8]
// ];
// let [[a,b,c,d],newArr]=arr //?[a,b,c,d]-деструетизируем
// console.log(a,b,c,d,newArr);
//1 2 3 4 (4) [5, 6, 7, 8]


//TODO Задание №2
//  Дан объект { name: "Петр", surname: "Петров", age: "20 лет" }.
// Запишите соответствующие значения в переменные name, surname и age.
// let obj ={ name: "Петр",
//  surname: "Петров",
//   age: "20 лет" 
// };
//   let{name,surname,age}=obj;
//   console.log(name,surname,age);

  //!пример
// let person={
//         age:30,
//         name:'John',
//         lastname:"Snow"
//     };
//     // let name=person.name;
//     // let age=person.age;
//     // let lastname=person.lastname;
// //? способ короче
//     let{age,name,lastname}=person;
//     console.log(name,age,lastname);

//TODO Задание №3
// Дан массив.
// let task3 = [
//     "первый",
//     "второй",
//     "третий",
//     "четвертый",
//     "пятый",
//     "шестой",
//     "седьмой"
// ];
// Запишите последний элемент этого массива в переменную elem1,
// а предпоследний - в переменную elem2.
// let task3 = [
//         "первый",
//         "второй",
//         "третий",
//         "четвертый",
//         "пятый",
//         "шестой",
//         "седьмой"
//     ];
// let [,,,,,elem2,elem1]= task3;
// console.log(elem2,elem1);


// TODO Задание №4
// Напишите функцию, которая принимает массив из чисел в качестве аргумента.
// Каждое число возвести в квадрат. Затем, функция должна вернуть измененный массив.
// Деструктурируйте полученный результат, т.е. первый элемент записать в переменную, а остальные элементы
// сохранить в новом массиве.



// [1, 2, 3, 4, 5].forEach(function(num, i, nums) {
//     console.log(num * num); // 2 4 6 8 10
//   });
//   let [a,...other]=i
//   console.log(a,other)

//   let arr = [1,2,3,4,5];
  

// function checkTask(arr) {
//     let newArr =[];
//     arr.forEach( num =>
//         newArr.push(num*num)
//         );
//         return newArr; 
// };
// let [a,...other]=checkTask([1,2,3,4,5]);
// console.log(a,other);

// TODO Задание №5
// Дан объект {name: 'Luck', 'age': '22', }.
// Запишите соответствующие значения в переменные name, и age.
// Сделайте так, чтобы если какое-то значение не задано - оно принимало значение по умолчанию.


// let person = {
//     // name: 'Luck', 
//     age: '22', }
// let{name = 'Аноним', age = '0 лет'} = person;
// document.write(name + ' ' + surname + ' ' + age);
// console.log(name,age);

let person = {
    name: 'Luck', 
    age: '22', }
let{name = 'Аноним', age = '15 лет'} = person;

console.log(name,age);
//!БАДО УРОК

//!ДЕСТРУКТУРИЗАЦИЯ МАССИВА
// const arr = [100, 200, 300, 400, 500];
// let [a, b, c, d, e] = arr;
// console.log(a, b, c, d, e);

//todo REST OPERATOR собирает остатки
// let [a, ...other] = arr;
// console.log(a);
// console.log(other);
// console.log(arr);

//todo ПОДМЕНА ДАННЫХ
// let zero = 2;
// let one = 1;
// let two = 0;
// [zero, one, two] = [two, one, zero];
// console.log(zero);
// console.log(one);
// console.log(two);

//?todoобращение к элементу массива 
// const color =["red"];
// const [firstColor="blue"]=color;
// //? если не будет red то дефолтное значение будет blue
// console.log(frstColor);

//! Деструктуризация объекта
//  let artist={
//      name:"Travis",
//      lastName:"Scott",
//      position:"rapper",
     
//  };
//  let {name,lastName,position}=artist;
//  console.log(name);
//  console.log(lastName);
//  console.log(position);
//?перезаписываем ключи в перменные

// let {name:newName,lastName:newLastName,position:newPosition}=artist;
// console.log(newName);
// console.log(newLastName);
// console.log(newPosition);
// console.log(artist);


//! Деструктуризация строки
// let str ="plus ultra".split(" ");
// let [str1,str2]=str;//? тут разделились на буквы что бы были слова исп split
// console.log(str1);
// console.log(str2);

//! spread operator
// let arr1=['hello','Bye','spasibo'];
// let arr2=[10,20,...arr1,30,40];
// console.log(arr2);
//* [10, 20, 'hello', 'Bye', 'spasibo', 30, 40]



// //todo
// let arr1=['hello','Bye','spasibo'];
// let arr3=[...arr1];
// //todo let arr3=arr1 это он присвоил и они все будут менятся как исходный а [...arr1] просто копирует данные
// console.log(arr3);
// arr3.push(1000);//? push добавляет в конец unshift добавляет в начало
// console.log(arr3);
// console.log(arr1);

//?слияние массива
// let a=[20,30];
// let b=[400,500];
// let arr=[...b,...a];
// console.log(arr);


// let letters="abcd";
// let arr = [...letters];
// console.log(arr);
//*['a', 'b', 'c', 'd']


//?слияние объекта

// let obj1={name:"tyler",age:33};
// let obj2={name1:"Josh",age2:32};//? если ключи одинаковые то что ниже заменяет первый поэтому name1 age1 что бы добавить
// let resObj={...obj2,...obj1}
// console.log(resObj);


// let obj3= {...obj1,status:true,name:"jack"};//?добавили несущ-е полеstatus:true и перезаписал name Jack так как ключ одинаковый
// console.log(obj3);//*{name: 'tyler', age: 33, status: true};

// function f1(a,...b){
//     console.log(a);
//     console.log(b);
// }
// f1(1,2) //? 1 [2]
// f1(1,2,3,4,5,6565,76766,98808,4,3,5,65,7)


//!глубокое копирование не распростроняется к методам не получится
// const car ={color:"red",wheels:{amount:4,shape:"round"}};
// //todo поверхностное копирование spread
// let car2 ={...car};
// console.log(car2.wheels.amount);
// car2.wheels.amount=5 //?перезапишем на 5
// console.log(car2);
// console.log(car);
//todo глубокое копирование- не меняет данные в исходных данных которые глубоко находятся JSON

// const car ={color:"red",wheels:{amount:4,shape:"round"}};
// let car2= JSON.parse(JSON.stringify(car));
// car2.wheels.amount=5 //?перезапишем на 5
// console.log(car2);
// console.log(car);


// let user={
//     name:"Asap",
//     sayHello:function() {
//     console.log(this.name);    
//     }
// };
// user.sayHello();
// // let newUser = JSON.parse(JSON.stringify(user));
// console.log(newUser);


// //!
// let person1 = { 
//     name: 'Jack', 
//     age: 19, 
//     favoriteFood: ['Lagman', 'Manty'], 
//     pet: { 
//         name: 'Sharik', 
//         age: 2, 
//     }, 
//     study: { 
//         university: 'KSTU', 
//         subjects: ['Math', 'Literature'], 
//         location: { 
//             str: 'Manas str 66', 
//             city: 'Bishkek', 
//         }, 
//     }, 
// }; 
// let { 
//     favoriteFood: [a, b], 
//     pet: { 
//         name 
//     }, 
//     study: { 
//         university, 
//         subjects: [, lit], 
//         location:{city}, 
//         mail='index' 
//     } 
// } = person1; 
// //todo get: lagman and manty, sharik, KSTU, Literature, Bishkek, mail index 
 
// console.log(`${a} and ${b}`); 
// console.log(name); 
// console.log(university); 
// console.log(lit); 
// console.log(city); 
// console.log(mail);

