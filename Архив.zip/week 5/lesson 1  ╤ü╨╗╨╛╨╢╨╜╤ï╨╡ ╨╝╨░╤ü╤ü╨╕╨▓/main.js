// let arr = [1,2,3,4,5,6,7,8,9];
// for(let i=0; i < arr.length; i++){
//     console.log(arr[i])
// }

//другой способ

//!ForEach() - перебиает массив и дает массиву отпраленную функцию
// let arr = [1,2,3,4,5,6,7,8,9];
// arr.forEach ((item,index,array)=>{
// console.log(item);
// console.log(index);
// console.log(array);
// })

//!MAP-создет новый массив и закидывает туда новые элементы над которыми были сделаны действия
// arr.map((value,index,array)=>{
// console.log(item);
// console.log(index);
// console.log(array)
// })

// let newArr=arr.map((item)=>{
// return item+10
// })
// console.log(newArr);

//!filter-принимает колбэк ф-ю которая должна возвращать нам либо true либо false и закидываются в новый массив и закидывается туда отфтдбтрованные значения
// let arr = [1,2,3,4,5,6,7,8,9];
// let newArr = arr.filter((item,index,array)=>{
// return item >4
// })
// console.log(newArr);

//* 5) [5, 6, 7, 8, 9]
// 0: 5
// 1: 6
// 2: 7
// 3: 8
// 4: 9
// length: 5

// let arr =[1,2,3,4,5,6,7,8,9,10]
// let newArr=arr.filter(item=>{
//     return item%2===0
// })
// console.log(newArr);  //*(5) [2, 4, 6, 8, 10]

// let str ='Ivan, Misha,Andrei,Oleg,Aktan';
// let filteredArr = str.split(',').filter(item =>{
//     return item.length>4
//todo return /a/gi.test(item)
//todo ищем имена в которых есть буква А с помощью regex
// })
// console.log(filteredArr);///*(3) [' Misha', 'Andrei', 'Aktan']

//!IndexOf
// let arr =['Ivan', 'Misha','Andrei','Oleg','Aktan'];
// let index = arr.indexOf('Oleg')
// console.log(index);

//!findIndex()возвращает иенно тру или фолс ( в каком порядке находится Олег ао 2 )
// let arr =['Ivan', 'Misha','Andrei','Oleg','Aktan'];
// let index =arr.findIndex((item,index,array) =>{
//  return item.length===10
// })
// console.log(index);//todo  возвращает первый элемент с  длиной 5 1-true -1-false

//!find() возвращает  именно сам Элемень а именно Олег и только первый который нащел
// let arr=[
//     {
//         name:"Ivan"
//     },
//     {
//         name:"John"
//     },
//     {
//         name:"Oleg"
//     },
//     {
//         name:"Aktan"
//     },
//     {
//         name:"Emily"
//     }
// ]
// console.log(arr.find(item =>item.name=== "Oleg"));
// console.log(arr.findIndex(item =>item.name=== "Oleg"));

//!Every- возвратит тру или фолс если для каждого элеменьа нашего массива callback будет возвращать тру
//todo так как 10 это строчный и он не подходит для цифр то показывает false
//todotypeof - определяет тип данных
// let arr=[1,2,3,"10",12,24];
// let result =arr.every((item,index,array)=>{
//     return typeof item ==="number"
// })
// console.log(result);

//!Some возвращает true в том случае если хотябы один элемент цифра
// let arr=[1,2,3,"10",12,24];
// let result = arr.some((item)=>{
//     return typeof item ==="number"
// })
// console.log(result);

//!includes(element,fromIndex)
//todo fromIndex- с какого индекса будем искать
// let arr=[1,2,3,4,5,6,7,8,9];
// let result=arr.includes(9,3);
// console.log(result);  //* ищи 9 начиная с 3

//! reduce()-сводит все элменты к единственному значению
// let arr=[1,2,3,4,5,6,7,8,9];
// let result =arr.reduce((prevVal,currVal,currIndex,array)=> {
// console.log(prevVal)-содержалась 1 предидущий;
// console.log(currVal)-все элеманты не считая 1 текущий;
// console.log(currIndex)-индексы текущих элементов ( какой порядок);
// console.log(array) сам массив
// })

// let arr=[1,2,3,4,5,6,7,8,9];
// let =arr.reduce((prevVal,currVal) => {
//      //todo или просто (a,b)=>
//     return prevVal+currVal
// })
// console.log(result);//* 45  сумма всех чисел

// todo Задание №1
// Дан массив из чисел: let nums = [12, 10, 99, 9, 3, 2, 120, 200,];
// Используя метод filter(), выведите в массив числа, которые больше или равны 10.
// Вывод: [12, 10, 99, 120, 200]

// let nums = [12, 10, 99, 9, 3, 2, 120, 200,];
// let newNums = nums.filter((item)=>{
// return item >= 10
// })
// console.log(newNums);

//todo Задание №2
// Дан массив let lengthName = [`Patricia` , `William` , `Barbara` , `James` , `Chloe` , `Elizabeth` ]; Преобразуйте каждый элемент в его длину и выведите в console. Используйте метод map().

// let lengthName = [`Patricia` , `William` , `Barbara` , `James` , `Chloe` , `Elizabeth` ];
// lengthNAme=lengthName.map(item=>{
//     return item.length;
// })
// console.log(lengthName);

//todo Задание №3
// Дан массив let arrNums = [12, 21, 27, 31, 45, 50 ];
//  С помощью цикла foreach и оператора if выведите в console элементы массива, которые больше 20-ти, но меньше 30-ти.

// let arrNums = [12, 21, 27, 31, 45, 50 ];
// arrNums.forEach(item=>{
//     if(item>20&& item<30){
//         console.log(item);
//     }
// })

//todo Задание №4
// Дан массив let total = [ 1, 5, 0, 3, 6 ];
// Суммируйте все значения в данном массиве и выведите результат в alert(). Используйте метод reduce().
// let total = [ 1, 5, 0, 3, 6 ];
// let res = total.reduce((a,b)=>a+b);
// alert(res)

//!БАДО

// const people = [
//     {
//       name: 'Tanjiro',
//       age: 13,
//       salary: 250,
//       status: 'alive',
//     },
//     {
//       name: 'Nezuko',
//       age: 12,
//       salary: 300,
//       status: 'alive',
//     },
//     {
//       name: 'Zenitsu',
//       age: 16,
//       salary: 250,
//       status: 'alive',
//     },
//     {
//       name: 'Inosuke',
//       age: 15,
//       salary: 300,
//       status: 'alive',
//     },
//     {
//       name: 'Tengen',
//       age: 23,
//       salary: 400,
//       status: 'alive',
//     },
//     {
//       name: 'Rengoku',
//       age: 20,
//       salary: 500,
//       status: 'dead',
//     },
//   ];

//   for (let i=0;i<people.length;i++){
//       console.log(people[i]);
//   }
//!ForEach
//? выполняет указанную ф-ю один раз для каждого элемента в массиве (но не создает новый массив)
// people.forEach(function(person,index,array) {
// console.log(person);
// });
//? укороченный вид
// people.forEach((person)=>console.log(person))

//!map
//? создает новый массив с результатом вызова указанной ф=ии для каждого элемента

// const newPeople =people.map((person)=>{
// return person.name;
//* return `${person.name} ${person.age}`
// ** return person.age+10;
// });
// console.log(newPeople);

//!Filter
//? создает новый массив со всеми элементами, которые прошли проверку, задаваемую в передаваемой функции

// let adults = people.filter((person) => person.age >= 15);
// console.log(adults);

//!REDUCe
//? применяет ф-ю к каждому элементу массива возвращая одно результирующее значение

//  let amount =0;
//  for (let i=0;i<people.length;i++){
//      amount +=people[i].salary;

//  }
// console.log(amount);

// const amount = people.reduce((total,person)=>{
//     return total + person.salary;
// },1000);//?считай с 1000  сумма всех salary
// console.log(amount);

//  //? c буквами
//  let name=["m","a","k","e","r","s"];
//  let newArr = name.reduce ((a,b)=> a+b);

//  console.log(newArr);

// let arr = [4, 5, 5, 5, 3, 5, 2, 3, 1, 3, 4]
// function checkTask(arr){
// let countItems = arr.reduce((acc, item) => {
//   acc[item] = acc[item] ? acc[item] + 1 : 1;
//   console.log(acc[item]);
//   return acc;
// }, {});

// const result = Object.keys(countItems).filter((item) => countItems[item] > 1);
// let max = Math.max.apply(null,result);
//   return console.log(max);
//  }
//  checkTask(arr)

//!Find
//?  возвращает значение первого найденного элемента, удовлетворяющего условию переданному ф-ии или undefined если не найдет

// const nezuko = people.find((person)=> person.name==="Nezuko");
// console.log(nezuko);
//! findIndex
//?  возвращает индекс первого найденного элемента, удовлетворяющего условию переданному ф-ии или (-1) если не найдет
// const nezukoInd =people.findIndex((person)=>person.name === "Nezuko");
// console.log(nezukoInd);
//! EVERY (true/false)
//? провреяет удовлетворяют ли ВСЕ элементы массива заданному условию
// const alive= people.every((person)=>person.status==="alive")
// console.log(alive);//*false
//!Some (true/false)

//?провреяет удовлетворяет ли Какой нибудь элементы массива заданному условию
// const dead= people.some((person)=>person.status==="dead")
// console.log(dead);//*true

//!IndexOf
//?возвращает первый индекс по которому данный элемент может быть найден в массиве или -1 если нет такого элемента

//*массив вверху
// const arr=["Tanjiro", "Nezuko" , "Zenitsu", "Inosuke"];//* надо создать отдельный массив потому что вверху nezuko находится в блоке
// const showIndex = arr.indexOf("Nezuko");
// console.log(showIndex);

//! includes (true/false)
//? определяет содержит ли массив определенный элемент (true/false)
// const arr=["Tanjiro", "Nezuko" , "Zenitsu", "Inosuke"];
// const isThere =arr.includes("Nezuko");
// console.log(isThere);
// //? ищет элемент но не может захожить в объект поэтму надо задать через пример ARR

//TODO У вас есть массив объектов user, и в каждом из них есть user.name. Напишите код, который преобразует их в массив имён.

// let users = [
//     { name: 'Kim', age: 41 },
//     { name: 'Kortney', age: 42 },
//     { name: 'Khloe', age: 37 },
//     { name: 'Kendall', age: 26 },
//     { name: 'Kylie', age: 24 },
//   ];
//   let names = users.map((person) => {
//         return `$ {person.name} `;
//     }) ;
//     /* ... ваш код */
//     console.log(names); // Kim, Kortney, Khloe, Kendall,Kylie

//TODO Напишите функцию getAverageAge(users), которая принимает массив объектов со свойством age и возвращает средний возраст. Формула вычисления среднего арифметического значения: (age1 + age2 + ... + ageN) / N.

// function getAverageAge(arr) {
//     return users.reduce((prev, user) =>  prev + user.age / arr.length, 0);
//   }
//   console.log(getAverageAge(users));

//!! ТАСКИ
// todo Задание 1
// Вам дана функция checkTask, принимающая массив arr с числами, выведите в консоль массив, в котором будут только положительные числа из массива arr.

// Например:

// checkTask([2, 3, 5, 9, 8, -11, 6, 7, 47, 53, -1, -3, 17])
// Вывод:

//  [2, 3, 5, 9, 8, 6, 7, 47, 53, 17]
// Используйте метод filter()

// function checkTask(arr){
//     let newArr=arr.filter((item)=>{
//         return item>0
//     })
//     console.log(newArr);
// }
// checkTask([2, 3, 5, 9, 8, -11, 6, 7, 47, 53, -1, -3, 17])

// todo Задание 2
// Вам дана функция checkTask, принимающая массив arr с числами. Используя метод forEach() найдите сумму элементов массива.

// Например:

// checkTask([10, 25, 25, 15, 5, 10])
// Вывод:

// 90

// let arr = [10, 25, 25, 15, 5, 10];
// function checkTask(array) {

//     let sum = 0;
//     array.forEach(( item )=> {
//             return sum += item;
//         });
//         console.log(sum);
// }
// checkTask(arr)

// todo Задание 3
// Вам дана функция checkTask, принимающая массив arr с числами. Используя метод reduce(), вычтите числа в массиве начиная с начала и выведите в консоль результат.

// Например:

// checkTask( [175, 50, 25])
// Вывод:

// 100
// т.к 175-50-25=100

// function checkTask(arr){
//     let newArr=
// }

//  //?первый способ
// let arr=[175, 50, 25];
// let result =arr.reduce((a,b) => {
//     return a-b
// })
// console.log(result);

// //?второй способ

// function checkTask(arr){
//     let newArr = arr.reduce((a,b)=>a-b)
//     console.log(newArr);
// }
// checkTask(arr)

//todo Задание 4
// Напишите функцию checkTask(arr), которая принимает в аргументы массив и возвращает элемент массива с максимальным значением.

// К примеру, для массива:

// [4, 15, -4, 27, 12, 8];
// Возвращенным значением будет:

// 27
// Нельзя использовать sort()!

// function checkTask(arr){
//     arr=Math.max(...arr)
//     console.log(arr);
// }

//todo Задание 5
// Напишите функцию checkTask(arr), принимающая в аргументы массив с числами.

// Функция должна найти самое часто повторяющееся число и вывести в консоль это число.

// Например, для массива:

// [4, 5, 5, 5, 3, 5, 2, 3, 1, 3, 4]
// Вывод будет:

// 5

// let arr = [4, 5, 5, 5, 3, 5, 2, 3, 1, 3, 4]
// function checkTask(arr){
// let countItems = arr.reduce((acc, item) => {
//   acc[item] = acc[item] ? acc[item] + 1 : 1;
//   return acc;
// }, {});

// const result = Object.keys(countItems).filter((item) => countItems[item] > 1);
// let max = Math.max.apply(null,result);
//   return console.log(max);
//  }
//  checkTask(arr)

//todo Задание 6
// Данa функция checkTask(arr), принимающая в аргументы массив с числами.

// Используя forEach() и push(), создайте новый массив, состоящий из квадратов этих чисел.

// Результат возвратите из функции.

// Например, для массива:

// [1, 2, 3]
// Возвращенным значением будет:

// [1, 4, 9]

// let checkTask = arr => {
//     NewArr =[];
//     arr.forEach( num =>
//         newArr.push(num*num)
//         );
//         return newArr
// };

// todo Задание 7
// Дана функция checkTask(arr), принимающая в аргументы массив с числами.

// Используя метод every(), проверьте то, что все элементы в массиве больше нуля.

// Например, если в arr будет хранится массив вида:

// [4, 5, 8, 9]
// то выводом в консоли будет:

// true
// результат, возвращаемый функцией, должен быть типом данных Boolean

// function checkTask(arr){
//     let res=arr.every(num=>num>0)
//     console.log(res)
//    }
//    checkTask([4, 5, 8, 9]);

// todo Задание 8
// Напишите функцию checkTask(arr), принимающую в аргументы массив со строками.

// Используя метод filter(), оставьте в массиве только те строки, длина которых больше пяти символов.

// Результат выведите в консоль.

// Например, для массива:

// ['июнь', 'октябрь', 'май', 'ноябрь', 'март']
// Вывод будет:

// ['октябрь','ноябрь']

// let arr = ['июнь', 'октябрь', 'май', 'ноябрь', 'март']
// function checkTask(arr){
// let newArr = arr.filter(item => {
//     return item.length > 5
// })
// return console.log(newArr)
// }
// checkTask(arr)

// todo Задание 9
// Напишите функцию checkTask(arr), принимающую в аргументы массив с числами.

// Используя метод reduce(), найдите сумму всех элементов до первого нуля.

// Результат выведите в консоль.

// Например, для массива:

// [1, 2, 3, 0, 4, 5, 6]
// суммируем первые 3 элемента, так как дальше стоит элемент с числом 0.

// Вывод будет:

// 6

//     function checkTask(arr) {
//         let arr2;
//         arr.reduce((a, b) => {
//           if (b === 0) {
//             return (arr2 = a);
//           } else if (a === 0) {
//             return (arr2 = 0);
//           } else {
//             return a + b;
//           }
//         });
//     //? if(typeof(arr2) === 'undefined' ){
//     //?     arr2=0
//     return console.log(arr2);
// }
// checkTask(arr)

// todo Задание 10
// Напишите функцию checkTask(arr), принимающую в аргументы массив вида:

// ["Это заголовок <h1>", "А это параграф <p>", "А это тег <div>"]
// Используя метод includes() и любой метод перебора массива оберните каждый элемент массива в соотвутсвующий тег(т.е добавьте нужные строки-теги в начале и в конце элемента массива).

// Вывод должен быть следующим, в первом console.log'е нужно показать:

// <h1>Это заголовок <h1></h1>
// затем:

// <p>А это параграф <p></p>

// и в конце:

// <div>А это тег <div></div>
// ВАЖНО: В массиве используются только теги h1, p, div, других тегов в массиве не будет

// let arr = ['Это заголовок <h1>', 'А это параграф <p>', 'А это тег <div>'];
// let checkTask = (arr) => {
//   arr.forEach((i) => {
//     if (i.includes('<h1>')) {
//       console.log(`<h1>${i}</h1>`);
//     } else if (i.includes('<p>')) {
//       console.log(`<p>${i}</p>`);
//     } else if (i.includes('<div>')) {
//       console.log(`<div>${i}</div>`);
//     }
//   });
// };
// checkTask(arr);

// todo Задание 11
// Напишите функцию checkTask(arr), принимающую в аргументы массив состояший из других массивов.

// Функция должна создать объект из вложенных массивов, используя метод reduce().

// Первый элемент внутреннего массива, должен быть ключом, второй - значением объекта.

// Результат выведите в консоль.

// Например, для массива:

// [['a', 1], ['b', 2]]
// Вывод будет:

// {'a': 1, 'b': 2}

//todo Задание 12
// Напишите функцию checkTask(arr), принимающую в аргументы массив состояший из других массивов.

// Используя метод reduce(), найдите сумму всех элементов.

// Результат выведите в консоль.

// Например, для массива:

// [1,2, [4,5,6], [7,8]]
// Вывод будет:

// 33

// let arr=[1,2, [4,5,6], [7,8]] ;
// function checkTask(arr){
//     let arr1=arr.reduce((a,b)=>{
//         if (typeof(a) !=`object`){
//             a=[a] //? тут массив преарвтили в объект если ноборот то надо методом flat
//         }
//         return a.concat(b) //? делает один массив общий
//     },0);
//     let result=arr1.reduce((a,b)=>a+b)
//     return console.log(result)
// }
// checkTask(arr)

//todo Задание 13
// Напишите функцию checkTask(arr), принимающую в аргументы массив состояший из чисел, а также из чисел типа BigInt(большие числа)

// Сумма всех цифр внутри одного числа, будет равна ASCII номеру определенной буквы.

// Используя map(), reduce() соберите по буквам зашифрованную фразу. Результат выведите в консоль.

// Например, для массива:

// [584131398786538461382741n, 444521974525439455955n, 71415168525426614834414214n, 353238892594759181769n, 48955328774167683152n, 77672648114592331981342373n, 5136831421236n,
// 83269359618185726749n, 2554892676446686256n, 959958531366848121621517n, 4275965243664397923577n, 616142753591841179359n, 121266483532393851149467n, 17949678591875681n]

// Выводом будет строка:

// secret-message

//todo Задание 8
// Создайте функцию checkTask(arr), которая принимает в аргументы массив с числами.

// Функция должна вычислять сколько элементов с начала массива надо сложить, чтобы в сумме получилось 10.

// Для массива:

// [3, 1, 4, 2, 4, 5, 6]
// Функция должна возвратить:

// 4

//  function checkTask(arr) {
//   let arr2;
//           arr.reduce((sum, elem) => {
//             if (sum === 10) {
//               return (arr2 = sum)
//             } else {
//                     sum++
//               return a + b;
//             }
//           });
//        return console.log(arr2);
//      }
//   checkTask([3, 1, 4, 2, 4, 5, 6] )

//todo Задание 1
// Напишите функцию checkTask(arr), которая получает в качестве параметра массив.

// Функция должна перебрать все его элементы и вывести сам элемент, а также тип данных элемента - числовой, либо не числовой.

// К примеру, для массива:

// ['Молоко', -77, 11, 'Мед', -88]
// Вывод будет следующим:

// Молоко - не число
// -77 - число
// 11 - число
// Мед - не число
// -88 - число
// Аргументы для вывода в консоль передавайте через запятую, например
// console.log(item, '-', "не число")

//   let arr = ['Молоко', -77, 11, 'Мед', -88];
//   function checkTask(arr) {
//     let newArr = arr.map((item) => {
//   if (typeof item === "string") {
//       console.log(`${item}- не число`);
//   } else {
//       console.log(`${[item]}- число`);
//   };
// });
// return console.log(newArr);
//       }
// checkTask(arr);

// todo Задание 2
// Напишите функцию checkTask(elem, arr), принимающую элемент elem и массив arr.

// Функция определяет, присутствует ли заданный элемент в массиве.

// В качестве результата работы функции можно выдавать логическое значение true и индекс этого элемента, если элемент найден, и false — в противном случае.

// Пример, для массива ['Молоко', 20, 40, 'дом', 30] и элемента 40, вывод будет:

// true 2
// Для элемента 'Hello' вывод будет:

// false
// Аргументы для вывода в консоль передавайте через запятую, например console.log(true, index)

// let arr = ['Молоко', 20, 40, 'дом', 30]

// function checkTask(elem, arr) {
//     arr.forEach((item, index) => {
//         if (item === elem) {
//             return console.log(true, index);
//         } else {
//             return console.log(false);
//         }
//     });
// }
// checkTask(40, arr)

//todo Задание 3
// Напишите функцию checkTask(arr), которая будет принимать массив из чисел.

// Ваша функция должна находить сумму чисел методом forEach(), методом reduce() и map().

// Для массива [5, 6, 7, 8, 9] вывод будет:

// forEach: 35
// reduce: 35
// map: 35

// let arr = [5, 6, 7, 8, 9];
// function checkTask(array) {
//     let sum = 0;
//     array.forEach(( item )=> {
//             return sum += item;
//         });
//         console.log(`forEach: ${sum}`);
// }
// checkTask(arr)

// let sum1 = arr.reduce((sum, elem) => {
//     return sum + elem
// })
// console.log(`reduce: ${sum1}`);

// let sum2 = arr.map((value) =>{
//     return value
// })
// console.log(`map: ${sum1}`);

// todo Задание 4
// Создайте функцию checkTask(arr), принимающую массив, состоящий из строк.

// Функция должна возвращать массив, содержащий только те строки, длина которых равна или больше пяти символов.

// Для массива:

// ['aaa', 'aaaqqq', 'zzzqq', 'zz', 'qsaa', 'q', 'az']
// Вывод будет:

// ['aaaqqq', 'zzzqq']
// Используйте filter()

//? первый способ стрелочная
// let arr =['aaa', 'aaaqqq', 'zzzqq', 'zz', 'qsaa', 'q', 'az'];
// let filteredArr = arr.filter(item =>{
//     return item.length >=5
// })
// console.log(filteredArr);

//? второй способ
// let arr = ['aaa', 'aaaqqq', 'zzzqq', 'zz', 'qsaa', 'q', 'az'];
// function checkTask(arr){
// let newArr = arr.filter(item => {
//     return item.length >= 5
// })
// return console.log(newArr)
// }
// checkTask(arr)

//todo Задание 5
// Создайте функцию checkTask(arr), принимающую массив, в нем могут быть обычные элементы и подмассивы.

// Функция должна возвращать массив, содержащий только подмассивы.

// Для массива:

// [1, 2, [3, 4], 5,[6, 7]]
// Вывод будет:

// [[3, 4],[6, 7]]
// Используйте метод filter()

//  let arr = [1, 2, [3, 4], 5, [6, 7]];
// function checkTask(arr) {
//   let newArr = arr.filter(index => {
//       return typeof(index) == 'object'
//   })
//   return newArr}
// checkTask(arr);

//todo  Задание 6
// Создайте функцию checkTask(arr), принимающую массив и элемент массива, и удаляет переданный элемент из массива.

// Например для аргументов [2, 5, 9, 6] и 5, вывод будет:

// [2, 9, 6]

//todo Задание 7
// Создайте функцию checkTask(arr), которая принимает в аргументы массив с числами.

// Найдите сумму первых N элементов до первого нуля. Функция должна возвращать сумму.

// К примеру для массива:

// [1, 2, 3, 0, 4, 5, 6]
// Функция возвратит:

// 6
// Используйте slice() и reduce().

//?первый способ

// let arr = [1, 2, 3, 0, 4, 5, 6];
// let answer = 0;
// let result = arr.reduce(function(sum, elem) {
// 	if (elem == 0) {
// 		answer = sum;
// 	} else {
// 		return sum + elem;
// 	}
// });
// if(answer == undefined){answer = result};
// console.log(answer);;

//?второй способ
// let arr = [1, 2, 3, 0, 4, 5, 6];

// function checkTask(arr) {

//     const sum = arr.slice(0, arr.findIndex(e => e === 0)).reduce((total, amount) => total + amount);

//     return console.log(sum);
// }
// checkTask(arr)

//?третий способ
// function checkTask(arr) {
//         let arr2;
//         arr.reduce((a, b) => {
//           if (b === 0) {
//             return (arr2 = a);
//           } else if (a === 0) {
//             return (arr2 = 0);
//           } else {
//             return a + b;
//           }
//         });
//     //? if(typeof(arr2) === 'undefined' ){
//     //?     arr2=0
//     return console.log(arr2);
// }
// checkTask(arr)

//todo Задание 8
// Создайте функцию checkTask(arr), которая принимает в аргументы массив с числами.

// Функция должна вычислять сколько элементов с начала массива надо сложить, чтобы в сумме получилось 10.

// Для массива:

// [3, 1, 4, 2, 4, 5, 6]
// Функция должна возвратить:

// 4

//     let arr = [3, 1, 4, 2, 4, 5, 6]
//     function checkTask(arr){
//     let num = 1;
//     let result = arr.reduce(function(sum, elem) {
// 	if (sum >= 10) {
// 		console.log(num);
// 		return;
// 	} else {
// 		num++;
// 		return sum + elem;
// 	}
// });
// return result
// }
// checkTask(arr)

//todo Задание 9
// Создайте функцию checkTask(arr), которая принимает в аргументы массив состоящий из строк и выводит в консоль новый массив состояший только из первых и последних букв каждой строки.

// Например, для массива:

// ['hi', 'goodbye', 'smile']
// Вывод будет:

// ['hi', 'ge', 'se']

// let arr = ['hi', 'goodbye', 'smile'];
// function checkTask(arr) {
//     let newArr = arr.map((item) =>{
//         return item[0] + item[item.length -1]
//     })
//     return console.log(newArr);
// }
// checkTask(arr)

//todo Задание 10
// Создайте функцию checkTask(arr), которая принимает в аргументы массив состоящий из чисел.

// Функция должна вывести количество отрицательных чисел в этом массиве.

// Для массива:

// [7, -1, -9, 0, 4, 5, -6]
// Вывод будет:

// 3

// let arr = [7, -1, -9, 0, 4, 5, -6];
// function checkTask(arr) {
//     let sum = 0;
//     let newArr = arr.map((item) => {
//         if (item < 0){
//             sum++
//         }
//     })
//     return console.log(sum);
// }
// checkTask(arr)

// todo Задание 11
// Напишите функцию checkTask(arr), принимающую в аргументы массив.

// Функция должна перемешивать элементы массива случайным образом.

// Каждый вызов данной функции должен возвращать массив с разным порядком элементов массива.

// Результат выведите в консоль.

// Например, для массива:

// [4, 8, 12, 16]
// Вывод будет:

// [8, 16, 4, 12]
// Следующий вызов, возвратит другой порядок элементов:

// [12, 4, 16, 8]

// let arr =[4, 8, 12, 16]
//  function checkTask(arr){
// let arr1 = arr.sort(function() {
//     return .5 - Math.random();
// });
// return console.log(arr1);
// }
// checkTask(arr)

// todo Задание 12
// Создайте функцию checkTask(arr), которая принимает в аргументы массив.

// Функция должна вывести в консоль массив содержащий только уникальные элементы.

// К примеру, для массива:

// ['apple', 'orange', 'apple', 'pear']
// Вывод будет:

// ['apple', 'orange', 'pear']

// let arr = ['apple', 'orange', 'apple', 'pear']
// function checkTask(arr){
//     let arr1.filter(item,index)=> arr1.indexof(item)===index)
// }
// checkTask(arr)

// let arr = ['apple', 'orange', 'apple', 'pear']
// arr.form(new Set(arr))
// console.log(arr);

//? не получается ф-я
// let arr = ['apple', 'orange', 'apple', 'pear']
// function checkTask(arr){
// let uniАrr = [...new Set(arr)];
// return console.log(uniАrr);
// }
// console.log(arr);

// todo Задание 13
// Напишите функцию checkTask(str) которая принимает строку и выводит в консоль объект с ключами в виде гласных, и значениями ключей в виде чисел, обозначающих сколько раз данная гласная встречается в заданной строке.

// Функция не должна учитывать регистр, т.е должна учитывать и заглавные и строчные буквы.

// Например, для строки:

// 'I Am awesome and so are you'
// Вывод будет:

// {i: 1, a: 4, e: 3, o: 3, u: 1}
// Использовать forEach()

// let arr = [1, 2, 3, 1, 2, 9, 10];
// let newArr = arr.splice(5, 1, 15);
// console.log(arr);

let num = 1000;
for (let i = 0; i < num; i++) {
  if (num[i] % 2 == 0) {
  } else if (num[i] === 50) {
    break;
  }
  console.log(num[i]);
}
