// console.log("Hello World!");

// let example = "Hello world 2";
// const example2 = "Hello World 3";

// console.log(example);
// console.log(example2);

// let name = "Kani";
// name = "Makers";
// console.log(name);


// 1. String
// let str = "Hello world";
// let str1 = "Hello";
// let str2 = "5";
// console.log( str, str1, str2)


//2.Number

// let num = 25;
// let num2 = 12.25;
// console.log ( num , num2)

//3.Boolen
// let bool1 = true;//yes
// let bool2 = false;//no
// console.log(bool1);
// console.log(bool2);
// console.log(Boolen(1))


//4. Undefined -не спец пустота 
// let a
// console.log(a)

//5.Null- спец пустота 
// let b = null;
// console.log(b);

//6.Object относится к сложному типу данных
// let obj = {
//     name: "kani", 
//     "last-name": "Arstanbaeva",
//     age: 22, 
//     hobby: null, 
//     isHuman: true,
//     dog: {
//         name: "Oreo",
//         color: "black",
//     }
// }
// console.log(obj);
// console.log(obj.name);
// console.log(obj.age);
// console.log(obj[ "last-name"]);
// console.log(obj.isHuman);
// console.log(obj.dog.name)обращаемся у имнеи собаки ;
// console.log(obj.dog.color)


//ARRY -массив

// let arr= [1,2,3,4,true,false,undefined,null,"hello",{name: "Kani"}[7,8,9],90,"world",];
// console.log(arr);
// console.log(arr[4]);
// console.log(arr[8]);
// console.log([6]);
// console.log([10][1]);
// console.log(arr.length);
// console.log(arr.length-1);
