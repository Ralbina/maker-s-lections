// console.log(true && false);
// console.log(true && true);

// console.log( true ||false);
// console.log(false||false);
// console.log(ture||true);


// console.log(!true);

// true || false && true;
// true|| false;
// true



// true && (false|| (true||false))
// будет true

 

// let response = prompt ("How old are you?");
// if (response >= 18){
//     alert("Allowed")
// } else if(confirm("Do your parents allow?")){
//     alert("ok")
// }
// else{
//     alert("Forbidden")
// }

// let age=prompt ("Enter your age")
// let name=prompt("Enter your name").toLowerCase//все что мы ввеедем переведет в нижний регистр (даже с больщой)
// if(age>=18 && name ==="admin"){
//     alert("Welcome, Admin!")
// }else if (age>=18){
//     alert("Hello User!")
// }
// else{
//     alert("Forbidden")
// } 



//todo Логические операторы
// let sum = 5 + 2;
// switch (sum){
//     case 6: alert(" Мало")
//     break
//     case 7: alert ( "Неправильно")
//     break
//     case 8: alert("Правильно")
//     break
//     case 9: alert ( "Слишком много")
// }


// let age =+prompt ("Enter your age");//конвертируем age в число (вместо строки ) с помощью +
// console.log(age);
// switch(age){
//     case 15:  alert(" Watch Naruto");
//     break;
//     case 18: alert ("Watch Shreck");
//     break;
//     case 20: alert ("Watch Avengers");
//     break ;
//     default: alert ("Watch Harry Potter")
// }