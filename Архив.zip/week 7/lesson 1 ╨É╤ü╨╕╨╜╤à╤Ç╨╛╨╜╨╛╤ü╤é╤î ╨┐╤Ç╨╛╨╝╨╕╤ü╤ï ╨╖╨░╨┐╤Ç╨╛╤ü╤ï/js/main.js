// for(let i=0; i<10000000000000; i++){

// }
// console.log('hello')

// todo асинхронная
// setTimeout(()=>{
//     console.log(1);
// },2000)
// console.log(2);

// function func() {

//     console.log('Hello 1');
// }
// setTimeout(func,1000)// по истечении 1 секунды
// setTimeout(()=>{
//     console.log('Hello 2');
// })
// console.log('Hello3');ё



// let i=0
// const id=setInterval(() => {
    
//     console.log(`hello ${++i}`);
// }, 1000);//? через кажлую секунду вызывает ф-ю
//  setTimeout(()=>{
//      clearInterval(id)
//  },5000) //? на пяти секунд останавливает запуск ф-ии



//!Promise
// const age=20
// const newPromise = new Promise(function(resolve,reject){
//     if(age >= 21){
//         resolve({age,status:true})
//     }else{
//         reject({age,status:false})
//     }
// })
// newPromise
// .then((result)=>console.log(result,'SUCCESS'))
// //? then  ловится только успешный результат 
// .catch((error)=> console.log(errore,"ERROR");)
// //? ошибка не выходит потому что мы ее словили с помощью catch и выщел результат сообщение ERROR
// .finally(()=>console.log('Finish');)
// //? будет работать в любом случае




// const p = new Promise((resolve, reject)=> {
//     setTimeout(() => {
//         resolve(new Promise((res.rej)=>{
//             setTimeout(() => {
//                 res('Say hello')
//             }, 1000);
//         }))
//     }, 1000)
// })
// p
// .then(promise => console.log(promise))
// .catch(error => console.log(error))

//!BADO


// const timer=setTimeout(function(text){
//     console.log(text);
// },2000,' ldd,;l,d');
// console.log(1);

// clearInterval(text)




// const btn=$('button');
// console.log(btn);
// let i=0;
// let timer;
// btn.on('click',()=> {
//     timer=setInterval(counter,1000);
// })
// function counter(){
//     if (i===3){
//         clearInterval(timer)
//     }
//     console.log('worked'+i);
//     i++;
// }




// function myAnimation(){
// const elem=$(".box");
// let pos=0


// const id = setInterval(frame, 10);
// function frame(){
//     if(pos===300){
//         clearInterval(id);
//     }
// pos++;
// elem.css('top',`${pos}px`);
// elem.css('left',`${pos}px`);
// }
// }
// const btn = $("button");
// btn.on("click",myAnimation)



//!Promise

// const p = new Promise((resolve,reject)=>{
// let a = 1+2;
// if (a===3){
//     resolve('Success');
// }else{
//     reject('Failure')
// }
// });


// p.then((message)=>{
//     console.log("This is in the THEN "+message);
// }).catch((message)=>{
//     console.log("This is in the CATCH "+message);
// }) .finally (()=>{
//     console.log("FINALLY");//todo тут сообщения не будет потому что он работает и с ошибками и с правильными 

// })
//todo Informational responses (100–199)
//todo Successful responses (200–299)
//todo Redirection messages (300–399)
//todo Client error responses (400–499)
//todo Server error responses (500–599)


//!запросы

// let btn=$("button");

//? XMLHTTPRequest

// const getData=()=>{
//     console.log("data");
//     const xhr= new XMLHttpRequest();
//     xhr.open("GET","https://reqres.in/api/users")//todo подотовка к отправке
//     xhr.send();//todo тут отправляем запрос
//     xhr.onload=()=>{
        // console.log(xhr.response);//todo onload ждем ответа
//         const data= JSON.parse(xhr.response);
//         console.log(data);
//     }

// };
// btn.on("click", getData);


//?AJAX только через JQuery делает get запрос автоматически
 
// $.ajax({
//     url: "https://reqres.in/api/users",
//     success: function(info){
//         console.log(info.data);
//     },
//     error: function (xhr) {
// console.log('Запрос не прошел со статусом'+ xhr.status);
//     },
// });


//? Fetch
// fetch("https://reqres.in/api/users")
    // .then((data)=>data.json()
    // .then((info)=>console.log(info)));

// //?data.json().then((info) это promise

// const div = $('div');
// fetch('https://reqres.in/api/users').then((data) =>
//   data.json().then((info) =>
//     info.data.forEach((person) => {
//       console.log(person);
//       div.append(
//         `
//         <div>
//         <span> ${person.first_name} </span>
//         <span> ${person.last_name} </span>
//          <img src=${person.avatar} alt=${person.first_name}>
//          <span> ${person.email} </span>
//          </div>`
         
//       );
//     })
//   )
// );


//!!!!!!!!<<<<<<<<<<<<< CLASS WORK>>>>>>>>>>>>>>>>>

// Используя API списка всех стран

// всех странах наподобие такой:
// API: https://restcountries.com/v3.1/all

// выведите таблицу с информацией о
// fetch('https://restcountries.com/v3.1/all')
//   .then((result) => result.json())
//   .then((data) => {
//     data.forEach((item) => {
//       let elem = `
//         <tr>
//         <td>${item.cca2}</td>
//         <td></td>
//         <td>${item.name.official}</td>
//         <td></td>
//         <td></td>
//         </tr>
//         `
//       $('tbody').append(elem)
//     });
//   });