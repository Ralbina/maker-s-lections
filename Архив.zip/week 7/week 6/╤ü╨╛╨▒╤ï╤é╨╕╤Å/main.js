// let btn=document.getElementById("btn")//тут мы поймали наш елемент

//todo 1способ
// btn.addEventListener("click", handler)
// //todo 2 способ
// btn.addEventListener("click", function(){
//     console.log("Hello Makers!");
// })//можнописать ф-/ внутри   .//? при нажатии выйдет в консоле запись
// //todo 3 способ
// btn.addEventListener("click",()=>{
//     console.log("Hello Bootcamp!");
// })
// //todo 4 способ
// btn.onclick=()=>alert("Hello!")

//?мы ждем когда произойдет событие click  то мы вызываем ф-ю которая будет являться нашим разработчиком событий handler
// btn.addEventListener("click", handler)
// btn.addEventListener("click",handler2)

// function handler (){
//     alert("Thank you!")
// }

// function handler2(){
//     alert ("Thank you again!")
// }
//todo удаление remove
// btn.removeEventListener("click",handler)//тут удалили ф-ю handler

// let h1 =  document.querySelector("h1")
// let inp = document.querySelector("#inp")

//todo change
//  inp.addEventListener("change", function(event){
//     //  console.log(event.target.value);
//      //?  value который находится в targrte котороый находится в event покажет в консоле  то что мы пишем в inpute

//      h1.innerText=event.target.value
//      //? тут показывает то что пишет пользователь только не в консоле а в странице
//       event.target.value=""
//       //? тут очищается в  inpute  то что мы пишем при нажатии на enter

//  })

// console.log(h1,inp);
//todo input

// inp.addEventListener("input", function(event){
//     h1.innerText=event.target.value
//     //? тут сразу отображается то что пишет пользователь не нажимая на enter
// console.log(event);
// })

//todo target показывает  на каком элеменье произошло событие

//todo keydown
// inp.addEventListener("keydown", function(event){
// console.log(event);
// h1.innerText=event.key;
// //? тут отобразит что пишем по одной букве  на какую клавищу мы нажимаем прямо сейчас

// })

//!BADO

// let btn = document.querySelector("#button");
// let body = document.querySelector("body");
// btn.addEventListener("click",)
// function changeColor(){
//     body.style.backgroundColor="red";
// }
// btn.removeEventListener("click", changeColor);

// let btn = document.querySelector("#button");
// btn.onclick=()=>{
//     btn.style.backgroundColor="pink";
// }
// const div = document.querySelector("#block");
// div.style.height= "200px";
// div.style.width= "200px";
// div.style.backgroundColor= "grey";

// // div.addEventListener("click",()=>{
// //     console.log("you clicked");
// //     div.style.backgroundColor= "yellow";
// //     //? меняет цвет когда нажал и отжал
// // });

// //todo СОБЫТИЯ

// div.addEventListener("mousedown",()=>{
//     console.log("mousedown");
//     div.style.backgroundColor= "blue";
//     //? меняет цвет когда нажимаем и держим
// });

// div.addEventListener("mouseup",()=>{
//     console.log("mouseup");
//     div.style.backgroundColor= "red";
//     //? меняет цвет когда отпускаем
// });

// div.addEventListener("dblclick",()=>{
//     console.log("dblclick");
//     div.style.backgroundColor= "pink";
//     //? меняет цвет при двойном нажатии

// });

// div.addEventListener("contextmenu",()=>{
//     console.log("contextmenu");
//     div.style.backgroundColor= "green";
//     //? меняет цвет при вызове контекстного меню
// });

// div.addEventListener("mouseover",()=>{
//     console.log("mouseover");
//     div.style.backgroundColor= "lightgreen";
//     //? меняет цвет при наведении мыши но не выходит из этого цвета

// });

// div.addEventListener("mouseleave",()=>{
//     console.log("mouseleave");
//     div.style.backgroundColor= "lightblue";
//     //? меняет цвет при отведении мыши но не выходит из этого цвета если ватоматически то использовать hover  в css
// });

// div.addEventListener("mousemove",()=>{
//     console.log("mousemove");
//     div.style.backgroundColor= "purple";
//     //? меняет цвет при каждом движении внутри
// });

// div.addEventListener("mouseover",()=>{
//     console.log("mouseover");
//     div.style.backgroundColor= "lightgreen";
//     //? меняет цвет при наведении мыши но не выходит из этого цвета
// });

// let check= document.querySelector("#check");
// check.addEventListener("change",(event)=>{
//     console.log(event.target.id);
// });

// !!Задачи

// При нажатии на Button 1, поменяйте фон у всех параграфов на "coral"
//  * Использовать цикл
//?первый способ
// const btn = document.querySelector('#button1');
// let p = document.getElementsByTagName('p');
// btn.addEventListener('click', () => {
//    for (let i = 0; i < p.length; i++) {
//        console.log(p[i])
//        p[i].style.backgroundColor='coral'
//    }
//    })

//? второй способ
//     let button1 = document.querySelector('#button1')
//  let p = document.querySelector('p')
// button1.addEventListener('mousedown',()=>{
//     p.style.backgroundColor = 'coral';
// })

//todo 1
// При нажатии на Button 1, поменяйте фон у всех параграфов на "coral"
// * Использовать цикл

//?несовсем правильный
//     let button1 = document.querySelector('#button1')
//  let p = document.querySelector('p')
// button1.addEventListener('mousedown',()=>{
//     p.style.backgroundColor = 'coral';
// })
//?правильный
// const btn = document.querySelector('#button1');
//  let p = document.getElementsByTagName('p');
//  btn.addEventListener('click', () => {
//     for (let i = 0; i < p.length; i++) {
//         console.log(p[i])
//         p[i].style.backgroundColor='coral'
//     }
//     })
//todo 2
//   * При нажатии на Button 1 замените все h2 на странице своим именем
//   * Использовать цикл

// const div = document.querySelector('#button1');
//  let title = document.getElementsByTagName('h2');
//  div.addEventListener('click', () => {
//     for (let i = 0; i < title.length; i++) {
//         console.log(title[i])
//         title[i].innerText = 'Kanykei, Begimai, Nurjan, Nuriza'
//     }

//     })

//todo 3
//  * При нажатии на Button 1 выберите элементы нумерованного списка
//  * с классом "falseFact" и замените текст на "True Fact".
//  * Использовать  метод массива

// let btn1 = document.querySelector('#button1');
// let li = document.querySelectorAll('.falseFact');
// console.log(li);
// btn1.addEventListener('click', ()=>{
//     li.forEach(x => {
//         x.innerHTML = 'trueFact'
//     })
// })

//todo 4
//  * При нажатии на кнопку 2, поменяйте фон страницы на розовый

// let body = document.querySelector('body');
// let btn = document.querySelector('#button2');
// btn.addEventListener('click', changeColor);
// function changeColor(){
//     body.style.backgroundColor="pink"
// }

//todo 5
//  * При нажатии на кнопку 2, поменяйте цвет всех h2 на зеленый
//  * Навесить событие как свойство ДОМ элемента (onclick)

// let zagalovok2 = document.querySelectorAll('h2');

// document.body.addEventListener('keydown', function (event) {
//   if(event.code == "Digit2") {
//     zagalovok2.forEach((x) => x.style.color = "green");
//   }
//   console.log(event.code)
// });

//todo 6
//  * При нажатии на кнопку 2, поместите внутрь тэга "blockquote"
//  "<span>no quote</span>"

// let btn2 = document.querySelector('#btn2');
// let block  = document.querySelector('blockquote')

// btn2.addEventListener('click', () => {
//    block.innerHTML="<span>no quote</span>"
// })

//todo 7
//  При нажатии на кнопку 3, поменяйте текст h1 на 'DOM is easy'.

// let button3 = document.querySelector('#button3')
// button3.innerHTML= '<button>Button3</button>'
//  let h1 = document.querySelector('h1')
// button3.addEventListener('click',()=>{
//     h1.innerText = 'DOM is easy'
// })

//todo 8
//  * При нажатии на кнопку 3, добавьте после h1, параграф
//  описывающий какое действие произошло, например нажали такую кнопку
//  в таком месте (указать координаты)

//todo 9
//  * При нажатии на кнопку 3, поменяйте цвет текста параграфов на красный
//  и шрифт на georgia

// let button3 = document.querySelector('#button3')
// let h1 = document.querySelector('h1')
// button3.innerHTML= '<button>Button3</button>'
// button3.addEventListener('click',()=>{
//     h1.style.color='red';
//     h1.style.fontFamily='georgia';
// })

// //!
// let btn = document.querySelector("#btn");

// const random = () => {
//   const rand = Math.random() * 80; // потому что рандомное число макс 1
//   return Math.floor(rand);
// };

// btn.addEventListener("mouseenter", () => {
//   btn.style.left = `${random()}%`;
//   btn.style.top = `${random()}%`;
// });
// btn.addEventListener("click", () => {
//   alert("Congrats!Whatrgklrjgkrjgrkl");
// });



//! ClassWork

// Задание №1
// По нажатию клавиш меняйте цвет заднего фона
// div - элемента:
// R - red;
// G - green;
// B - blue;
// w - white;
// SHIFT + B - black;
// SHIFT + G - gray;

// let div = document.getElementById("container");
// document.addEventListener("keydown", function (event) {
//   // console.log(event);
//   if (event.code === "KeyR") {
//     div.style.backgroundColor = "red";
//   } else if (event.code === "KeyG") {
//     div.style.backgroundColor = "green";
//   } else if (event.code === "KeyB") {
//     div.style.backgroundColor = "blue";
//   } else if (event.code === "KeyW") {
//     div.style.backgroundColor = "white";
//   }
// });

// Задание №2
// Создайте переменную let i=0, по нажатию
// на кнопку выводите в консоль переменную i
// и увеличивайте её в 2 раза;

// Задание №3
// Создайте div размером 500px * 500px,
// по нажатию на неё выводите в консоль
// позицию места куда вы нажали
// относительно div- а;

// Задание №4
// Создайте input type color.
// При изменении инпута меняйте цвет
// заднего фона body на значение
// из этого инпута
