// $('p').dblclick(function(){
//     $('p').hide();// hide прячет  при клике она исчезнет
// });
// //! передача одного события
// $(".mouse-enter").mouseenter(function(){
//     $(this).css('background-color','grey')
// });
//!передача нескольких событий через оn можно передать несколько событий
// $('.mouse-enter').on({
//     mouseenter: function () {
//       $(this).css('background-color', 'pink');
//     },
//     mouseleave: function () {
//       $(this).css('background-color', 'yellow');
//     },
//     click: function () {
//       $(this).css('background-color', 'red');
//     },
//   });

// $('#btn').click(function (e) {
//     console.log('ww');
//     $('.outer').append('<div class="inner"></div>'); //todo тут добавили inner так как в html там нет
// });

// //! добавление стилей динамически созданным эдементам
// $(document).on('click','.inner',function(e){
//     $(e.target).css('background-color','lightblue');//? при нажатии на черные квадраты они меняют цыет 
// })


//!animation

// $(document).on('keydown',function(e){
//     switch(e.which){
//         case 37:
//             $("#animated").finish().animate({
//                 left:'-=20px'
//             });
//             break;
//             case 38:
//             $("#animated").finish().animate({
//                 top:'-=20px'
//             });
//             break;
//             case 39:
//             $("#animated").finish().animate({
//                 left:'+=20px'
//             });
//             break;
//             case 40:
//             $("#animated").finish().animate({
//                 top:'+=20px'
//             });
//             break;
//     }
//     //?finish удаляет предидущие очередь анимации
// })




// $('form').submit(function (e) {
//   e.preventDefault();//? убирает перезагрузку form

//   let name = $('.inp-name').val();
//   let price = $('.inp-price').val();
//   let descr = $('.inp-descr').val();
//   let image = $('.inp-image').val();
//   console.log(name, price, descr, image);

//   if(!name||!price||!descr||!image){
//   alert('заполните все поля')
//   return
//   }

//   let data = `
//         <div class="card m3" style="width: 18rem;">
//   <img src='${image}' class="card-img-top" alt="...">
//   <div class="card-body">
//     <h5 class="card-title">Name: ${name}</h5>
//     <p class="card-text">Descr: ${descr}</p>
//     <a href="#" class="btn btn-primary">Price: ${price}</a>
//   </div>
// </div>`

//   $('.catalog').append(data);

//   $('.inp-name').val("");
//   $('.inp-price').val("");
//   $('.inp-descr').val("");
//   $('.inp-image').val("");//? тут данные в inpute удаляются
// })    //todo val - покажет в консоле то что мы заполняем в инпуте



///!!!CLASSWOR
// Классная работа. События jQuery

// Задание №1
// Создайте div элемент.
// По нажатию клавиш меняйте цвет заднего фона div - элемента:
// R - red;
// G - green;
// B - blue;
// w - white;
// SHIFT + B - black;
// SHIFT + G - gray;

// Задание №2
// В html создайте кнопку.
// Создайте переменную let i=0, по нажатию на кнопку выводите в консоль переменную i и увеличивайте её в 2 раза;

// Задание №3
// 	Создайте div размером 500px * 500px, по нажатию на неё выводите в консоль позицию места куда вы нажали относительно div- а;

// Задание №4
// Создайте input type color. При изменении инпута меняйте цвет заднего фона body на значение из этого инпута

// Задание №5
// Создайте <h3> тэги, всем тэгам поставьте текст '!!!'.


//!!!!ТАСКИ
// todo 2
// Создайте 5 тэгов <div> и выведите в консоль количество созданных тэгов
//? html
{/* <div class='num'>1</div>
<div class='num'>2</div>
<div class='num'>3</div>
<div class='num'>4</div>
<div class='num'>5</div> */}
//? JS
// let tag = document.querySelectorAll('div.num').length
// console.log(tag);

//todo 3
// Создайте обработчик нажатия на кнопку, который будет менять цвет фона страницы.
// let body = document.querySelector('body')
// let btn = document.querySelector('button')
// btn.addEventListener('click', changeColor)
// function changeColor(){
//     body.style.backgroundColor = 'pink'
// }