// console.log(typeof document.getElementById("title"));
// let title = document.getElementById("title");
// let items= document.getElementsByClassName("item");
// let items2 = document.querySelectorAll(".item")
// for (let i=0; i<items.length;i++){
//      console.log(items[i]);
//  }


// let example = document.getElementById("hello");
//  console.log(example.innerHTML);

// example.innerText="New Data";
// console.log(example.innerHTML);


//!Бадо
// console.log(document.documentElement);
// //? рутовый элемент самый важный
// console.log(document.head);
// console.log(document.body);
//!getElementsBy
// let title = document.getElementsByTagName("h1")
// console.log(title[0]);
// let list = document.getElementById("list");
// console.log(list);
// let elems= document.getElementsByClassName("elem");
// console.log(elems);
//!qoerySelector(All) 
// let elem=document.querySelectorAll(".elem");
// console.log(elem);
// let elem1=document.querySelectorAll(".elem");
// elem1.forEach((x)=>console.log(elem));
// let elem2=document.getElementsByClassName("elem");
// elem2.forEach((x)=>console.log(elem));//error

// console.log(elem1);
// console.log(elem2);


// let block = document.querySelectorAll("[name='blockName']");
// console.log(block);


// //! createElement , innerText, InnerHTML
// const newDiv=document.createElement("div");
// console.log(newDiv);//<div></div>

// newDiv.innerText="<p>i am text"//*<div>i am text</div>   //?заполнили текстом
// //? все будет видеть как текст даже теги


// newDiv.innerHTML="i am text"//? тут будет брать и теги если тут будет прописаны

 //!firstElementChild,lastElementChild

//  const list = document.querySelector("#list");
//  console.log(list.firstElementChild.innerText);
//  console.log(list.lastElementChild.innerText);
//! nextElementSibling родственниеи одного уровня т е родные брятья и сестра
// const div=document.querySelector("#block2");
// console.log(div.nextElementSibling); //? след родственный

// console.log(div.previousElementSibling);//? предидущий 

//!append prepend(сверху но в диве)/ befor after( на одном уровне)
// const ul=document.querySelector("ul");
// const newNode=document.createElement("li");
// newNode.innerText="Scala";
// ul.append(newNode)

// //todo prepend

// const newNode2=document.createElement("li");
// newNode2.innerText="Pascal";
// ul.prepend(newNode2)


// //todo before

// const newNode3=document.createElement("li");
// newNode3.innerText="Hello";
// ul.before(newNode3)

// //todo after

// const newNode4=document.createElement("li");
// newNode4.innerText="By";
// ul.after(newNode4)

//!setAttribute
// const block=document.querySelector("#block");
// const input= document.createElement("input")// создали инпут
// input.setAttribute("placeholder","Enter your name")
// block.prepend(input);

// //!classlist
// const block = document.querySelector("#block5");
// console.log(block5);
// //todo добаление класса
// block.classList.add("newClass")
// //todo удаление класса

// block.classList.remove("newClass")
// //todo удаление если есть, добавление если нет 
// block.classList.toggle("newClass")

// //todo проверка (true/false)
// console.log(block.classList.contains("newClass"));


// if(block.classList.contains("newClass")){
//     console.log("I have this class");
//     block.style.color="green"
// }else{
//     console.log("I dont have this class");
//     block.style.color="pink"
// }


//!style
// document.getElementById("block2").style.color="blue"
// document.getElementById("block3").style.backgroundColor="pink"
// document.getElementById("block3").style.backgroundColor=""
 
// let block=document.getElementById("block4")//? вытаскиваем
// block.setAttribute('style','width:200px; height:200px;border:2px solid yellow;background-color:grey')

//?3 способ
// let block = document.getElementById('block4');
// let styles = {
//     wight: '200px',
//     height: '200px',
//     border: '2px solid black',
//     'background-color': 'green'
// };

// Object.assign(block.style, styles)

//? 4 способ


// let styles = `
// font-size: 2em;
// color: red;
// background-color: beige;
// transform: rotate(10deg);
// `;
// // transform: scale(0,6) уменьшает увеличивает
// document.querySelector('*').style = styles;
//!appendchild vs append

// const parent=document.createElement("div");
// const child=document.createElement("p");
// parent.append(child);//? принимет только узлы домененов только элементов но не тектов 
// console.log(parent);


// const parent =document.createElement("div");
// parent.append("Appending Text")//todo текст вставится
// console.log(parent);

//todo !appendchild
// const parent=document.createElement("div");
// const child=document.createElement("p");
// parent.appendChild(child);//? принимет только узлы домененов только элементов но не тектов 
// console.log(parent);

// const parent =document.createElement("div");
// parent.appendChild("Appending Text")//todo тут уже не встаивтся ERROR
// console.log(parent);




// !!!DOM. Классная работа

// Задание №1
// 	Всем <h3> поставьте текст '!!!'.
// let h3 = document.getElementById("hello");
//  console.log(example.innerHTML);

// Задание №2
// 	Всем <h3> сделайте текст зеленого цвета.

// Задание №3
// 	Создайте маркированный список,
// При помощи цикла добавьте в маркированный
// список 30 li - элементов с текстом:
// “1 - овечка”, “2 - овечка”,
// “3 - овечка”,
// и так до “30-овечка”;

// Задание №4
// В css создайте класс .active в
// котором пропишите цвет текста blue.
// Добавьте всем span элементам класс active
// через document.getElementsByTagName.


//  function array(my_array) {
//     if (my_array.length === 1) {
//       return my_array[0];
//     }
//     else {
//       return my_array.pop() + array(my_array);
//     }
//   };
  
//  console.log(array([2,3,4]));


// let x = 3;
// function recursion(){
//     x++;
//     console.log(x);
//     if (x > 5) {
//         return x;
// }
//     recursion();
// }
//     recursion();


let h3s = document.getElementsByTagName('h3');
console.log(h3s);
for (i of h3s) {
  i.innerText = '!!!';
}