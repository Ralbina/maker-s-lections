
// let title=document.getElementsByTagName("h1")
// console.log((title));

//todo  тоже самое но только с помошью JQuery
// let title=$("h1");
// let welcome=$(".welcome");
// let titleById=$("#title");
// let inp= $("[name= 'inp-name']")
// // console.log(title, welcome, titleById, inp);

// titleById.style.color="red";

//!BADO
let header = $('h1');
let description = $('.description');
let functions = $('#functions');
let button = $('[name="btn-name"]');

// console.log(header);
// console.log(description);
// console.log(functions);
// console.log(button);

//? объект является статическим
// let items =$('li');
// console.log(items.length);//количество li(4)

// let lost = $('ol');
// list.append('<li>Scala</li>');
// console.log(items.length);//количество li(4)

// let item = $('ol li');
// console.log(item);
// let item = $('li.best')
// console.log(item[0].textContent);// получить текст внутри списка

//использование циклов
// let item = $('li.best')
// for (i of item){
//     console.log( ${i.textContent});
// }

//как можно обратиться через соседей
// let text = $('h1 + p');
// console.log(text);

//обратиться к li у которого есть класс
// let classy = $('li[class]');
// console.log(classy);

// проверка кнопки check !!! не работает
// let check = $("input[type='checkbox']");
// console.log(check[0].cheked);

//!   =================STYLE=================

header.css("background-color","peurple");
button.css({
    "background-color":'orange',
    with:'200px',
    height:"50px",
    border:'none'

})

//!===================Фильтры===================
// $('p').css('background-color','gold');
// $('p:last').css('background-color','gold')//?окрасится последниц
// $('p:first').css('background-color','gold');
// $('p:odd').css('background-color','gold')//? окрасит четные
// $('p:even').css('background-color','gold')//? не четные
// $('p:eq(1)').css('background-color','gold')//?окрасит по индексу
// $('p:gt(2)').css('background-color','gold')//? окрашивается после того индекса, который указали 
// $('p:lt(3)').css('background-color','gold')//? окрасится перед того индекса который указали

// $('p:not(.description)').css('background-color','gold')//? окрасит все помимо того у которого есть класс descripsion

$('p:has(span).css('background-color','gold')//? фильтр по содержимому нащео div он только в одном


