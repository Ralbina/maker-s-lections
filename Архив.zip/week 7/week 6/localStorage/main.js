// let btn = $('.btn');
// let inp = $('.task-input');
// let list =$('.task-list');
// // todo вытащили наши элементы

// btn.on('click',function(){
//     // console.log(inp.val()); // todo то что мы введем в инпут высветится в консоле
//     // let value =inp.val()
//     // list.append(`<li>${value}</li>`);
//     //todo отобразится в браузере то что написали в инпуте
    
    
    
//     let obj={
//         task: inp.val()
//     }
//     setItemToStorage(obj)
// })

// function setItemToStorage(task){
//     localStorage.setItem('tsaks-data',JSON.stringify(task))
//     // localStorage.getItem
// }




// //!!!!BADO
// todo LOCALSTORAGE
// localStorage.setItem('breakfest','eggs')
// localStorage.setItem('lunch','soup')

// let lunch = localStorage.getItem('lunch');
// // console.log(lunch);

// localStorage.removeItem('lunch');
// //?clear
// localStorage.clear();

// //TODO SESSION STORAGE
// sessionStorage.setItem('breakfest','eggs')
// sessionStorage.setItem('lunch','soup')

// let lunch = sessionStorage.getItem('lunch');//? в консоле
// // console.log(lunch);

// // sessionStorage.removeItem('lunch');
// //?clear
// sessionStorage.clear();


// let local = $('#local')
// let session = $('#session')
// console.log(local, session);

// local.on('click', () => {
//     localStorage.setItem('breakfast', 'eggs');
// });

// session.on('click', () => {
//     sessionStorage.setItem('language', 'JS');
// });


//!!!!MINI PROJECT+SEARCH
let title=$('#title')
let price=$('#price')
let descr=$('#descr')
let image=$('#image')
let btnadd=$('.btnadd')
let productlist=$("#product-list")


let search=$("#search")
let searchVal=""
console.log(title,price,descr,image,btnadd,productlist,search);

btnadd.on('click', function(){
    let newProduct={
title:title.val(),
price:price.val(),
descr:descr.val(),
image:image.val(),
id: String(Date.now())
    }
let products = JSON.parse(localStorage.getItem('products'))||[];
products.push(newProduct)
console.log(products);
localStorage.setItem("products", JSON.stringify(products))
$('#title').val('')
$('#price').val('')
$('#descr').val('')
$('#image').val('')//?очищать инпут каждый раз
render()//? тут пишем что бы видеть карточки сразу без перезагрузки сайта

});


function render(){
    let products=JSON.parse(localStorage.getItem('products'));
if (!products){
    localStorage.setItem('products',JSON.stringify([]))
}
console.log(products);
productlist.html('')//?очищает нащ productlist что бы втсавить productlist уже с изменениями что бы не дублировалось 
products=products.filter((item)=>item.title.toLowerCase().includes(searchVal.toLowerCase()))
products.forEach((item)=>{
    // console.log((item));//?покажет объект по отдельности
    productlist.append(`
    <div class="card" style="width: 18rem;">
  <img src=${item.image} class="card-img-top" alt=${item.title}>
  <div class="card-body">
    <h5 class="card-title">${item.title}</h5>
    <p class="card-text">${item.descr}</p>
    <a href="#" class="btn btn-primary">${item.price}</a>
    <a href="#" class="btn-delete btn btn-danger"id="${item.id}">DELETE</a>

  </div>
</div>
    `
    )
})
} 
render()
function deleteProduct(id){
    let products=JSON.parse(localStorage.getItem("products"));
    products= products.filter((item)=>item.id !== id); 
    //? item.id -перебирает все ID
    //? ищет id который хоти удалить 
    localStorage.setItem("products",JSON.stringify(products))//? тут мы уже вставляем productlidt уже с удаленной карточкой
    render()
}
$(document).on('click','.btn-delete',function(e){
    deleteProduct(e.target.id);
})

search.on('input', function(e){
    // console.log(e.target.value);
    searchVal=(e.target.value);
    render()
})