// let xhr = new XMLHttpRequest();
// console.log(xhr);
// xhr.open('GET','http://localhost:8000/todos');
// xhr.send();
// xhr.onload = function(){
//     //  console.log(xhr.response);
//     let data =JSON.parse(xhr.response);
//     console.log(data);
// }
const API='  http://localhost:8000/products'
//? переменные для инпутов ( для добавления товаров)
let inp=$(".inp")
let title = $('#title');
let price=$('#price')
let descr=$('#descr')
let image=$('#image')
let btnAdd=$('#btn-add')
//? блок куда добавляются товары
let list=$('#product-list')

//?
let search=$('#search')
let searchVal='';


console.log(inp, title,price,descr,image,btnAdd,search,list);

render();


btnAdd.on('click', function () {
    let obj = {
      title: title.val(),
      price: price.val(),
      descr: descr.val(),
      image: image.val(),
    };
    setItemToJson(obj);
    inp.val('')
  });
  
  function setItemToJson(obj) {
    fetch(API, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json;charset=utf-8',
      },
      body: JSON.stringify(obj),
    }).then(()=>{
        render();
    })
  }
  function render(){
      fetch(API)
      .then((res)=>res.json())
      .then((data)=>{
          list.html('')//? что бы не было дублирования карточке в БД
          data.forEach((element)=>{
              let item =drawProductCard(element);
              list.append(item)
          })
        //   console.log(data);
      });
  }
  function drawProductCard(element){
  return `
  <div class="card m-3" style="width: 18rem;">
  <img src="${element.image}" class="card-img-top" alt="${element.title}">
  <div class="card-body">
    <h5 class="card-title">${element.title}</h5>
    <p class="card-text">${element.descr}</p>
    <p class="card-text">$ ${element.price}</p>
    <a href="#" class="btn btn-danger btn-delete" id=${element.id}>Delete</a>
    <a href="#" class="btn btn-dark" id=${element.id} data-bs-toggle="modal" 
    data-bs-target="#exampleModal">Edit</a>
  </div>
</div>
`;
}
$("body").on("click",".btn-delete",(e)=>deleteProduct(e.target.id));
async function deleteProduct(id){
    await fetch(`${API}/${id}`, {
        method:'DELETE',
    });
    render()
}





